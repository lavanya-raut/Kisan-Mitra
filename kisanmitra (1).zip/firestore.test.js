const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const FARMER_A = "farmer_ramesh_01";
const FARMER_B = "farmer_suresh_02";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProfile(uid, ts = new Date(Date.now() - 5000)) {
  return {
    userId: uid,
    fullName: "Ramesh Patil",
    email: "ramesh@example.com",
    phone: "+91 9876543210",
    village: "Wardha",
    district: "Nagpur",
    state: "Maharashtra",
    farmSizeAcres: 5.5,
    soilType: "Black Cotton",
    irrigationType: "Drip",
    preferredCity: "Nagpur",
    latitude: 21.1458,
    longitude: 79.0882,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validCrop(uid, ts = new Date(Date.now() - 5000)) {
  const now = Date.now();
  return {
    userId: uid,
    cropType: "Wheat",
    variety: "HD-2967",
    plotName: "North Plot",
    areaAcres: 2.5,
    sowingDateMillis: now - 20 * 86400000,
    expectedHarvestMillis: now + 100 * 86400000,
    currentStage: "Vegetative",
    healthStatus: "Healthy",
    progressPercent: 35,
    notes: "Good germination after first irrigation",
    createdAt: ts,
    updatedAt: ts,
  };
}

function validReminder(uid, ts = new Date(Date.now() - 5000)) {
  return {
    userId: uid,
    title: "Apply First Urea Top Dressing",
    category: "Fertilizer",
    cropName: "Wheat",
    cropId: "crop_1",
    scheduledDateMillis: Date.now() + 86400000,
    timeLabel: "07:00 AM",
    repeatFrequency: "Once",
    completed: false,
    notes: "Apply 25 kg per acre after light irrigation",
    createdAt: ts,
    updatedAt: ts,
  };
}

function validActivity(uid, ts = new Date(Date.now() - 5000)) {
  return {
    userId: uid,
    title: "Completed Drip Irrigation",
    activityType: "Irrigation",
    cropName: "Wheat",
    cropId: "crop_1",
    activityDateMillis: Date.now() - 3600000,
    quantityUsed: "2 hours drip",
    costInr: 450.0,
    notes: "Soil moisture restored uniformly",
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Unauthenticated users cannot read or write any KisanMitra collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(FARMER_A).get());
  await assertFails(unauthDb.collection("users").doc(FARMER_A).set(validProfile(FARMER_A)));
  await assertFails(unauthDb.collection("users").doc(FARMER_A).collection("crops").get());
  await assertFails(unauthDb.collection("users").doc(FARMER_A).collection("reminders").get());
  await assertFails(unauthDb.collection("users").doc(FARMER_A).collection("activities").get());
});

test("Farmer profile CRUD, PII isolation, and shadow update rejection", async () => {
  const dbA = testEnv.authenticatedContext(FARMER_A).firestore();
  const dbB = testEnv.authenticatedContext(FARMER_B).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(dbA.collection("users").doc(FARMER_A).set(validProfile(FARMER_A, created)));
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).get());

  // Cross-user PII read/write denied
  await assertFails(dbB.collection("users").doc(FARMER_A).get());
  await assertFails(dbB.collection("users").doc(FARMER_A).update({ fullName: "Hijacked", updatedAt: new Date(Date.now() - 1000) }));
  // Users root list denied
  await assertFails(dbA.collection("users").get());

  // Valid partial update
  await assertSucceeds(
    dbA.collection("users").doc(FARMER_A).update({
      preferredCity: "Pune",
      latitude: 18.5204,
      longitude: 73.8567,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field / shadow update
  await assertFails(
    dbA.collection("users").doc(FARMER_A).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    dbA.collection("users").doc(FARMER_A).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject future tampered timestamp
  await assertFails(
    dbA.collection("users").doc(FARMER_A).update({
      fullName: "Ramesh",
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("UserCrop create, list, growth update, validation, and cross-user isolation", async () => {
  const dbA = testEnv.authenticatedContext(FARMER_A).firestore();
  const dbB = testEnv.authenticatedContext(FARMER_B).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("crops").doc("crop_1").set(validCrop(FARMER_A, created)));
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("crops").get());

  // Cross-user access denied
  await assertFails(dbB.collection("users").doc(FARMER_A).collection("crops").get());
  await assertFails(dbB.collection("users").doc(FARMER_A).collection("crops").doc("crop_1").delete());

  // Growth stage partial update
  await assertSucceeds(
    dbA.collection("users").doc(FARMER_A).collection("crops").doc("crop_1").update({
      currentStage: "Flowering",
      healthStatus: "Healthy",
      progressPercent: 60,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject invalid cropType and invalid @DocumentId `id` key
  await assertFails(
    dbA.collection("users").doc(FARMER_A).collection("crops").doc("crop_bad").set({
      ...validCrop(FARMER_A, created),
      cropType: "Avocado",
    })
  );
  await assertFails(
    dbA.collection("users").doc(FARMER_A).collection("crops").doc("crop_id_leak").set({
      id: "crop_id_leak",
      ...validCrop(FARMER_A, created),
    })
  );

  // Owner delete succeeds
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("crops").doc("crop_1").delete());
});

test("FarmingReminder create, toggle completion, edit, delete, and isolation", async () => {
  const dbA = testEnv.authenticatedContext(FARMER_A).firestore();
  const dbB = testEnv.authenticatedContext(FARMER_B).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("reminders").doc("rem_1").set(validReminder(FARMER_A, created)));
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("reminders").get());

  // Toggle completed action
  await assertSucceeds(
    dbA.collection("users").doc(FARMER_A).collection("reminders").doc("rem_1").update({
      completed: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Cross-user denied
  await assertFails(dbB.collection("users").doc(FARMER_A).collection("reminders").get());
  await assertFails(dbB.collection("users").doc(FARMER_A).collection("reminders").doc("rem_1").update({ completed: false, updatedAt: new Date(Date.now() - 500) }));

  // Owner delete succeeds
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("reminders").doc("rem_1").delete());
});

test("FarmingActivity create, list, edit, delete, and negative cost rejection", async () => {
  const dbA = testEnv.authenticatedContext(FARMER_A).firestore();
  const dbB = testEnv.authenticatedContext(FARMER_B).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("activities").doc("act_1").set(validActivity(FARMER_A, created)));
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("activities").get());

  // Edit activity
  await assertSucceeds(
    dbA.collection("users").doc(FARMER_A).collection("activities").doc("act_1").update({
      costInr: 600.0,
      notes: "Updated diesel pump cost",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject negative cost
  await assertFails(
    dbA.collection("users").doc(FARMER_A).collection("activities").doc("act_bad").set({
      ...validActivity(FARMER_A, created),
      costInr: -50,
    })
  );

  // Cross-user denied
  await assertFails(dbB.collection("users").doc(FARMER_A).collection("activities").get());

  // Owner delete succeeds
  await assertSucceeds(dbA.collection("users").doc(FARMER_A).collection("activities").doc("act_1").delete());
});
