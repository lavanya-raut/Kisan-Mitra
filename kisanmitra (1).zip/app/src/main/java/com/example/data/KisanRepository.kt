package com.example.data

import android.content.Context
import com.example.R
import com.example.data.model.FarmConstants
import com.example.data.model.FarmerProfile
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UserCrop
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class KisanRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUid: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("Farmer must be signed in with Google before accessing Firestore.")
        if (expectedUid != null) {
            check(uid == expectedUid) { "Signed-in user changed; refusing cross-user operation." }
        }
        return uid
    }

    private fun userDoc(uid: String) = db.collection("users").document(uid)
    private fun cropsCollection(uid: String) = userDoc(uid).collection("crops")
    private fun remindersCollection(uid: String) = userDoc(uid).collection("reminders")
    private fun activitiesCollection(uid: String) = userDoc(uid).collection("activities")

    // --- REALTIME SNAPSHOT FLOWS ---

    fun observeProfile(userId: String): Flow<FarmerProfile?> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId"
        emitAll(
            userDoc(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            FarmerProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeCrops(userId: String): Flow<List<UserCrop>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId/crops"
        emitAll(
            cropsCollection(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UserCrop::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.sowingDateMillis }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeReminders(userId: String): Flow<List<FarmingReminder>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId/reminders"
        emitAll(
            remindersCollection(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FarmingReminder::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(compareBy<FarmingReminder> { it.completed }.thenBy { it.scheduledDateMillis })
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeActivities(userId: String): Flow<List<FarmingActivity>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId/activities"
        emitAll(
            activitiesCollection(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FarmingActivity::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.activityDateMillis }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    private fun logStreamErrorIfActive(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val toLog = firestoreError ?: (error as? Exception)
        if (toLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(toLog, operationType, path)
        }
    }

    // --- FARMER PROFILE OPERATIONS ---

    suspend fun ensureProfileExists(
        userId: String,
        displayName: String?,
        email: String?
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val docRef = userDoc(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val cleanName = (displayName?.trim()?.take(80)).takeUnless { it.isNullOrBlank() } ?: "Kisan Farmer"
                val payload = mapOf<String, Any?>(
                    "userId" to uid,
                    "fullName" to cleanName,
                    "email" to email?.trim()?.take(120),
                    "phone" to "",
                    "village" to "",
                    "district" to "Nagpur",
                    "state" to "Maharashtra",
                    "farmSizeAcres" to 2.0,
                    "soilType" to "Black Cotton",
                    "irrigationType" to "Borewell",
                    "preferredCity" to "Nagpur",
                    "latitude" to 21.1458,
                    "longitude" to 79.0882,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfile(userId: String, profile: FarmerProfile): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val cleanName = profile.fullName.trim().take(80)
            require(cleanName.isNotEmpty()) { "Farmer name cannot be empty." }
            val cleanCity = profile.preferredCity.trim().take(80).ifEmpty { "Nagpur" }
            val safeAcres = profile.farmSizeAcres.coerceIn(0.0, 100000.0)
            val safeSoil = if (profile.soilType in FarmConstants.SOIL_TYPES) profile.soilType else "Black Cotton"
            val safeIrrigation = if (profile.irrigationType in FarmConstants.IRRIGATION_TYPES) profile.irrigationType else "Borewell"

            val payload = mapOf<String, Any>(
                "fullName" to cleanName,
                "email" to profile.email.trim().take(120),
                "phone" to profile.phone.trim().take(20),
                "village" to profile.village.trim().take(100),
                "district" to profile.district.trim().take(100),
                "state" to profile.state.trim().take(80),
                "farmSizeAcres" to safeAcres,
                "soilType" to safeSoil,
                "irrigationType" to safeIrrigation,
                "preferredCity" to cleanCity,
                "latitude" to profile.latitude.coerceIn(-90.0, 90.0),
                "longitude" to profile.longitude.coerceIn(-180.0, 180.0),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userDoc(uid).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateWeatherLocation(
        userId: String,
        cityName: String,
        latitude: Double,
        longitude: Double
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val cleanCity = cityName.trim().take(80).ifEmpty { "Nagpur" }
            userDoc(uid).update(
                mapOf(
                    "preferredCity" to cleanCity,
                    "latitude" to latitude.coerceIn(-90.0, 90.0),
                    "longitude" to longitude.coerceIn(-180.0, 180.0),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- CROP CRUD & GROWTH TRACKING ---

    suspend fun addCrop(userId: String, crop: UserCrop): Result<String> {
        var docPath = "users/$userId/crops"
        return try {
            val uid = requireUserId(userId)
            val safeCropType = if (crop.cropType in FarmConstants.SUPPORTED_CROPS) crop.cropType else "Wheat"
            val cleanVariety = crop.variety.trim().take(60).ifEmpty { "Standard" }
            val cleanPlot = crop.plotName.trim().take(60).ifEmpty { "Main Field" }
            val safeArea = crop.areaAcres.coerceIn(0.1, 50000.0)
            val sowing = crop.sowingDateMillis.takeIf { it > 0L } ?: System.currentTimeMillis()
            val harvest = crop.expectedHarvestMillis.coerceAtLeast(sowing)
            val safeStage = if (crop.currentStage in FarmConstants.CROP_STAGES) crop.currentStage else "Sowing"
            val safeHealth = if (crop.healthStatus in FarmConstants.HEALTH_STATUSES) crop.healthStatus else "Healthy"
            val safeProgress = crop.progressPercent.coerceIn(0, 100)

            val docRef = cropsCollection(uid).document()
            docPath = docRef.path
            val payload = mapOf<String, Any?>(
                "userId" to uid,
                "cropType" to safeCropType,
                "variety" to cleanVariety,
                "plotName" to cleanPlot,
                "areaAcres" to safeArea,
                "sowingDateMillis" to sowing,
                "expectedHarvestMillis" to harvest,
                "currentStage" to safeStage,
                "healthStatus" to safeHealth,
                "progressPercent" to safeProgress,
                "notes" to crop.notes.trim().take(400),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateCrop(userId: String, crop: UserCrop): Result<Unit> {
        val path = "users/$userId/crops/${crop.id}"
        return try {
            val uid = requireUserId(userId)
            require(crop.id.isNotBlank()) { "Crop ID is required for update." }
            val safeCropType = if (crop.cropType in FarmConstants.SUPPORTED_CROPS) crop.cropType else "Wheat"
            val cleanVariety = crop.variety.trim().take(60).ifEmpty { "Standard" }
            val cleanPlot = crop.plotName.trim().take(60).ifEmpty { "Main Field" }
            val safeArea = crop.areaAcres.coerceIn(0.1, 50000.0)
            val sowing = crop.sowingDateMillis.takeIf { it > 0L } ?: System.currentTimeMillis()
            val harvest = crop.expectedHarvestMillis.coerceAtLeast(sowing)
            val safeStage = if (crop.currentStage in FarmConstants.CROP_STAGES) crop.currentStage else "Sowing"
            val safeHealth = if (crop.healthStatus in FarmConstants.HEALTH_STATUSES) crop.healthStatus else "Healthy"
            val safeProgress = crop.progressPercent.coerceIn(0, 100)

            cropsCollection(uid).document(crop.id).update(
                mapOf(
                    "cropType" to safeCropType,
                    "variety" to cleanVariety,
                    "plotName" to cleanPlot,
                    "areaAcres" to safeArea,
                    "sowingDateMillis" to sowing,
                    "expectedHarvestMillis" to harvest,
                    "currentStage" to safeStage,
                    "healthStatus" to safeHealth,
                    "progressPercent" to safeProgress,
                    "notes" to crop.notes.trim().take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateCropGrowth(
        userId: String,
        cropId: String,
        stage: String,
        healthStatus: String,
        progressPercent: Int,
        notes: String
    ): Result<Unit> {
        val path = "users/$userId/crops/$cropId"
        return try {
            val uid = requireUserId(userId)
            require(cropId.isNotBlank()) { "Crop ID is required." }
            val safeStage = if (stage in FarmConstants.CROP_STAGES) stage else "Vegetative"
            val safeHealth = if (healthStatus in FarmConstants.HEALTH_STATUSES) healthStatus else "Healthy"
            cropsCollection(uid).document(cropId).update(
                mapOf(
                    "currentStage" to safeStage,
                    "healthStatus" to safeHealth,
                    "progressPercent" to progressPercent.coerceIn(0, 100),
                    "notes" to notes.trim().take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCrop(userId: String, cropId: String): Result<Unit> {
        val path = "users/$userId/crops/$cropId"
        return try {
            val uid = requireUserId(userId)
            require(cropId.isNotBlank()) { "Crop ID is required." }
            cropsCollection(uid).document(cropId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- REMINDERS CRUD ---

    suspend fun addReminder(userId: String, reminder: FarmingReminder): Result<String> {
        var docPath = "users/$userId/reminders"
        return try {
            val uid = requireUserId(userId)
            val cleanTitle = reminder.title.trim().take(100)
            require(cleanTitle.isNotEmpty()) { "Reminder title is required." }
            val safeCategory = if (reminder.category in FarmConstants.REMINDER_CATEGORIES) reminder.category else "General"
            val cleanCrop = reminder.cropName.trim().take(60).ifEmpty { "All Crops" }
            val safeRepeat = if (reminder.repeatFrequency in FarmConstants.REPEAT_FREQUENCIES) reminder.repeatFrequency else "Once"
            val safeTime = reminder.timeLabel.trim().take(20).ifEmpty { "07:00 AM" }
            val scheduled = reminder.scheduledDateMillis.takeIf { it > 0L } ?: System.currentTimeMillis()

            val docRef = remindersCollection(uid).document()
            docPath = docRef.path
            val payload = mapOf<String, Any?>(
                "userId" to uid,
                "title" to cleanTitle,
                "category" to safeCategory,
                "cropName" to cleanCrop,
                "cropId" to reminder.cropId.trim().take(128).ifEmpty { null },
                "scheduledDateMillis" to scheduled,
                "timeLabel" to safeTime,
                "repeatFrequency" to safeRepeat,
                "completed" to reminder.completed,
                "notes" to reminder.notes.trim().take(300),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateReminder(userId: String, reminder: FarmingReminder): Result<Unit> {
        val path = "users/$userId/reminders/${reminder.id}"
        return try {
            val uid = requireUserId(userId)
            require(reminder.id.isNotBlank()) { "Reminder ID is required." }
            val cleanTitle = reminder.title.trim().take(100)
            require(cleanTitle.isNotEmpty()) { "Reminder title is required." }
            val safeCategory = if (reminder.category in FarmConstants.REMINDER_CATEGORIES) reminder.category else "General"
            val cleanCrop = reminder.cropName.trim().take(60).ifEmpty { "All Crops" }
            val safeRepeat = if (reminder.repeatFrequency in FarmConstants.REPEAT_FREQUENCIES) reminder.repeatFrequency else "Once"
            val safeTime = reminder.timeLabel.trim().take(20).ifEmpty { "07:00 AM" }
            val scheduled = reminder.scheduledDateMillis.takeIf { it > 0L } ?: System.currentTimeMillis()

            remindersCollection(uid).document(reminder.id).update(
                mapOf(
                    "title" to cleanTitle,
                    "category" to safeCategory,
                    "cropName" to cleanCrop,
                    "cropId" to reminder.cropId.trim().take(128),
                    "scheduledDateMillis" to scheduled,
                    "timeLabel" to safeTime,
                    "repeatFrequency" to safeRepeat,
                    "completed" to reminder.completed,
                    "notes" to reminder.notes.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleReminderCompleted(
        userId: String,
        reminderId: String,
        completed: Boolean
    ): Result<Unit> {
        val path = "users/$userId/reminders/$reminderId"
        return try {
            val uid = requireUserId(userId)
            require(reminderId.isNotBlank()) { "Reminder ID is required." }
            remindersCollection(uid).document(reminderId).update(
                mapOf(
                    "completed" to completed,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteReminder(userId: String, reminderId: String): Result<Unit> {
        val path = "users/$userId/reminders/$reminderId"
        return try {
            val uid = requireUserId(userId)
            require(reminderId.isNotBlank()) { "Reminder ID is required." }
            remindersCollection(uid).document(reminderId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- FARMING ACTIVITY HISTORY CRUD ---

    suspend fun addActivity(userId: String, activity: FarmingActivity): Result<String> {
        var docPath = "users/$userId/activities"
        return try {
            val uid = requireUserId(userId)
            val cleanTitle = activity.title.trim().take(100)
            require(cleanTitle.isNotEmpty()) { "Activity title is required." }
            val safeType = if (activity.activityType in FarmConstants.ACTIVITY_TYPES) activity.activityType else "Note"
            val cleanCrop = activity.cropName.trim().take(60).ifEmpty { "All Crops" }
            val dateMillis = activity.activityDateMillis.takeIf { it > 0L } ?: System.currentTimeMillis()
            val safeCost = activity.costInr.coerceIn(0.0, 10000000.0)

            val docRef = activitiesCollection(uid).document()
            docPath = docRef.path
            val payload = mapOf<String, Any?>(
                "userId" to uid,
                "title" to cleanTitle,
                "activityType" to safeType,
                "cropName" to cleanCrop,
                "cropId" to activity.cropId.trim().take(128).ifEmpty { null },
                "activityDateMillis" to dateMillis,
                "quantityUsed" to activity.quantityUsed.trim().take(60),
                "costInr" to safeCost,
                "notes" to activity.notes.trim().take(400),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateActivity(userId: String, activity: FarmingActivity): Result<Unit> {
        val path = "users/$userId/activities/${activity.id}"
        return try {
            val uid = requireUserId(userId)
            require(activity.id.isNotBlank()) { "Activity ID is required." }
            val cleanTitle = activity.title.trim().take(100)
            require(cleanTitle.isNotEmpty()) { "Activity title is required." }
            val safeType = if (activity.activityType in FarmConstants.ACTIVITY_TYPES) activity.activityType else "Note"
            val cleanCrop = activity.cropName.trim().take(60).ifEmpty { "All Crops" }
            val dateMillis = activity.activityDateMillis.takeIf { it > 0L } ?: System.currentTimeMillis()
            val safeCost = activity.costInr.coerceIn(0.0, 10000000.0)

            activitiesCollection(uid).document(activity.id).update(
                mapOf(
                    "title" to cleanTitle,
                    "activityType" to safeType,
                    "cropName" to cleanCrop,
                    "cropId" to activity.cropId.trim().take(128),
                    "activityDateMillis" to dateMillis,
                    "quantityUsed" to activity.quantityUsed.trim().take(60),
                    "costInr" to safeCost,
                    "notes" to activity.notes.trim().take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteActivity(userId: String, activityId: String): Result<Unit> {
        val path = "users/$userId/activities/$activityId"
        return try {
            val uid = requireUserId(userId)
            require(activityId.isNotBlank()) { "Activity ID is required." }
            activitiesCollection(uid).document(activityId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
