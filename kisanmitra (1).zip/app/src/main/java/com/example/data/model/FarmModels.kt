package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

object FarmConstants {
    val SUPPORTED_CROPS = listOf(
        "Wheat", "Rice", "Cotton", "Soybean", "Sugarcane", "Maize", "Tomato", "Onion"
    )

    val CROP_STAGES = listOf(
        "Seed Selection",
        "Sowing",
        "Germination",
        "Vegetative",
        "Flowering",
        "Fruiting",
        "Maturity",
        "Harvested"
    )

    val HEALTH_STATUSES = listOf(
        "Healthy",
        "Needs Water",
        "Pest Alert",
        "Nutrient Care"
    )

    val SOIL_TYPES = listOf(
        "Alluvial",
        "Black Cotton",
        "Red Loamy",
        "Sandy Loam",
        "Clay",
        "Laterite"
    )

    val IRRIGATION_TYPES = listOf(
        "Canal",
        "Borewell",
        "Drip",
        "Sprinkler",
        "Rainfed"
    )

    val REMINDER_CATEGORIES = listOf(
        "Irrigation",
        "Fertilizer",
        "Pest Control",
        "Weeding",
        "Sowing",
        "Harvesting",
        "Soil Test",
        "General"
    )

    val REPEAT_FREQUENCIES = listOf(
        "Once",
        "Daily",
        "Weekly",
        "Bi-Weekly"
    )

    val ACTIVITY_TYPES = listOf(
        "Sowing",
        "Irrigation",
        "Fertilizer",
        "Pesticide",
        "Weeding",
        "Growth Check",
        "Harvest",
        "Note"
    )

    fun defaultProgressForStage(stage: String): Int = when (stage) {
        "Seed Selection" -> 5
        "Sowing" -> 15
        "Germination" -> 28
        "Vegetative" -> 45
        "Flowering" -> 65
        "Fruiting" -> 80
        "Maturity" -> 92
        "Harvested" -> 100
        else -> 15
    }
}

@Keep
@IgnoreExtraProperties
data class FarmerProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val village: String = "",
    val district: String = "",
    val state: String = "",
    val farmSizeAcres: Double = 2.0,
    val soilType: String = "Black Cotton",
    val irrigationType: String = "Borewell",
    val preferredCity: String = "Nagpur",
    val latitude: Double = 21.1458,
    val longitude: Double = 79.0882,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserCrop(
    @DocumentId val id: String = "",
    val userId: String = "",
    val cropType: String = "Wheat",
    val variety: String = "",
    val plotName: String = "",
    val areaAcres: Double = 1.0,
    val sowingDateMillis: Long = 0L,
    val expectedHarvestMillis: Long = 0L,
    val currentStage: String = "Sowing",
    val healthStatus: String = "Healthy",
    val progressPercent: Int = 15,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FarmingReminder(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "Irrigation",
    val cropName: String = "All Crops",
    val cropId: String = "",
    val scheduledDateMillis: Long = 0L,
    val timeLabel: String = "07:00 AM",
    val repeatFrequency: String = "Once",
    val completed: Boolean = false,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FarmingActivity(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val activityType: String = "Irrigation",
    val cropName: String = "All Crops",
    val cropId: String = "",
    val activityDateMillis: Long = 0L,
    val quantityUsed: String = "",
    val costInr: Double = 0.0,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
