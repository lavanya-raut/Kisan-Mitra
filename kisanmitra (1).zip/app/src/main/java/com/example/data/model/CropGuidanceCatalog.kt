package com.example.data.model

data class StageGuidance(
    val stageName: String,
    val dayRange: String,
    val keyActions: String,
    val waterTip: String,
    val nutrientTip: String
)

data class CropGuide(
    val cropType: String,
    val hindiName: String,
    val season: String,
    val durationDays: Int,
    val defaultVariety: String,
    val popularVarieties: List<String>,
    val idealSoil: String,
    val idealTempRange: String,
    val seedRatePerAcre: String,
    val spacing: String,
    val irrigationSchedule: String,
    val fertilizerSchedule: String,
    val pestManagement: String,
    val harvestIndicators: String,
    val stages: List<StageGuidance>
)

object CropGuidanceCatalog {
    val allGuides: List<CropGuide> = listOf(
        CropGuide(
            cropType = "Wheat",
            hindiName = "Gehu",
            season = "Rabi (Nov – Apr)",
            durationDays = 125,
            defaultVariety = "HD-2967",
            popularVarieties = listOf("HD-2967", "HD-3086", "PBW-725", "Lok-1", "Sharbati"),
            idealSoil = "Well-drained loamy to clay loam (pH 6.0 – 7.5)",
            idealTempRange = "15°C – 25°C",
            seedRatePerAcre = "40 – 45 kg / acre",
            spacing = "20 – 22.5 cm row spacing",
            irrigationSchedule = "4 to 6 irrigations at critical stages: CRI (21 DAS), Tillering (40 DAS), Jointing (60 DAS), Flowering (80 DAS), and Milking (100 DAS).",
            fertilizerSchedule = "Basal: 25 kg N + 24 kg P2O5 + 16 kg K2O per acre. Top-dress 25 kg Nitrogen (Urea) at CRI and tillering stages.",
            pestManagement = "Watch for yellow/brown rust and aphids. Use resistant varieties, seed treatment with Carbendazim, and neem oil spray at early aphid spotting.",
            harvestIndicators = "Straw turns golden yellow, grains become hard and moisture drops below 14%.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Select certified rust-resistant seeds; treat with Trichoderma or Carbendazim.", "Ensure pre-sowing moisture (Palewa).", "Apply FYM 4 tonnes/acre during ploughing."),
                StageGuidance("Sowing", "Days 1 – 7", "Line sow at 4 – 5 cm depth with seed-cum-fertilizer drill.", "Light irrigation if topsoil is dry.", "Apply full Phosphorus & Potash + 50% Nitrogen."),
                StageGuidance("Germination", "Days 8 – 20", "Check uniform emergence; gap-fill sparse patches early.", "Avoid waterlogging in young seedlings.", "No top dressing needed yet."),
                StageGuidance("Vegetative", "Days 21 – 55", "Critical CRI & tillering stage; perform manual or selective weeding.", "Give first critical irrigation at 21 DAS.", "Top-dress remaining 50% Urea after CRI watering."),
                StageGuidance("Flowering", "Days 56 – 85", "Booting and ear-head emergence; scout for yellow rust and aphids.", "Maintain steady soil moisture; avoid stress.", "Foliar 1% NPK 19:19:19 if crop looks pale."),
                StageGuidance("Fruiting", "Days 86 – 105", "Milk and dough grain-filling period; protect from lodging.", "Light irrigation on calm evenings only.", "0.5% Potassium Nitrate foliar spray boosts grain weight."),
                StageGuidance("Maturity", "Days 106 – 120", "Withhold irrigation 12–15 days prior to harvest.", "Stop watering completely.", "None."),
                StageGuidance("Harvested", "Days 120 – 130", "Harvest before shattering; sun-dry grains to <12% moisture for storage.", "Keep threshed grain dry.", "Incorporate stubble or mulch for next crop.")
            )
        ),
        CropGuide(
            cropType = "Rice",
            hindiName = "Dhan / Chawal",
            season = "Kharif (Jun – Nov)",
            durationDays = 130,
            defaultVariety = "Basmati 1121",
            popularVarieties = listOf("Basmati 1121", "Swarna", "MTU-1010", "IR-64", "Sona Masoori"),
            idealSoil = "Clay or clay-loam with good water retention (pH 5.5 – 6.8)",
            idealTempRange = "22°C – 32°C",
            seedRatePerAcre = "10 – 12 kg (transplanted)",
            spacing = "20 cm × 15 cm hill spacing",
            irrigationSchedule = "Maintain 2–5 cm standing water from transplanting to dough stage; use Alternate Wetting & Drying (AWD) to save 25% water.",
            fertilizerSchedule = "40 kg N + 20 kg P2O5 + 20 kg K2O per acre in 3 splits (basal, active tillering, panicle initiation) plus Zinc Sulphate 10 kg/acre.",
            pestManagement = "Install pheromone traps for Yellow Stem Borer; avoid excess Urea to reduce Brown Plant Hopper (BPH) and Leaf Blast.",
            harvestIndicators = "80% panicles turn straw-colored and lower grains are firm without milkiness.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Soak seeds in salt solution to remove chaff; treat with Pseudomonas.", "Prepare raised wet nursery bed.", "Apply well-rotted compost to nursery."),
                StageGuidance("Sowing", "Days 1 – 25", "Raise healthy 21–25 day old seedlings; puddle main field cleanly.", "Keep nursery moist without submerging tips.", "Basal DAP + Potash + Zinc before transplanting."),
                StageGuidance("Germination", "Days 25 – 35", "Transplant 2 seedlings/hill at shallow 2–3 cm depth.", "Keep thin 2 cm water layer for establishment.", "Light starter N dose after 7 days."),
                StageGuidance("Vegetative", "Days 36 – 65", "Active tillering phase; run cono-weeder twice.", "Practice Alternate Wetting & Drying.", "Top-dress 1/3 Urea at 30 DAT."),
                StageGuidance("Flowering", "Days 66 – 95", "Panicle initiation & booting; scout for stem borer & leaf blast.", "Maintain 3–5 cm standing water strictly.", "Final Nitrogen + Potash split at panicle initiation."),
                StageGuidance("Fruiting", "Days 96 – 115", "Milky & dough grain filling; watch for BPH at plant base.", "Keep soil saturated, avoid deep flooding.", "Foliar 1% Potash for uniform grain filling."),
                StageGuidance("Maturity", "Days 116 – 128", "Drain field 10 days before harvest for uniform ripening.", "Drain standing water completely.", "None."),
                StageGuidance("Harvested", "Days 128 – 135", "Harvest at 20% grain moisture; thresh and dry to 13% moisture.", "Dry on clean tarpaulin.", "Store in airtight moisture-free bags.")
            )
        ),
        CropGuide(
            cropType = "Cotton",
            hindiName = "Kapas",
            season = "Kharif (May – Nov)",
            durationDays = 165,
            defaultVariety = "Bt Cotton BG-II",
            popularVarieties = listOf("Bt Cotton BG-II", "RCH-2", "Suraj", "MCU-5", "DCH-32"),
            idealSoil = "Deep black cotton soil (Vertisols) with good drainage (pH 6.5 – 8.0)",
            idealTempRange = "21°C – 35°C",
            seedRatePerAcre = "900 g – 1.2 kg / acre (2 packets)",
            spacing = "90 cm × 60 cm",
            irrigationSchedule = "Critical irrigation at squaring, flowering, and boll development; drip irrigation increases yield by 30%.",
            fertilizerSchedule = "48 kg N + 24 kg P2O5 + 24 kg K2O per acre; foliar Magnesium Sulphate 1% prevents leaf reddening.",
            pestManagement = "Use sticky traps for whitefly/jassids and pheromone traps (5/acre) for Pink Bollworm; spray Neem Seed Kernel Extract (5%).",
            harvestIndicators = "Fully opened fluffy dry bolls; pick in dry morning hours after dew evaporates.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Choose sucking-pest tolerant hybrids; include non-Bt refuge seeds.", "Deep summer ploughing to destroy pupae.", "Apply 5 tonnes FYM + neem cake."),
                StageGuidance("Sowing", "Days 1 – 10", "Dibbling on ridges at 4–5 cm depth after monsoon onset.", "Give light irrigation if sowing pre-monsoon.", "Basal 20% N + full P + 50% K."),
                StageGuidance("Germination", "Days 11 – 25", "Gap-fill within 10 days; thin to 1 healthy plant per hill.", "Ensure excess rainwater drains quickly.", "No extra fertilizer yet."),
                StageGuidance("Vegetative", "Days 26 – 60", "Inter-cultivation and earthing up; scout for jassids & aphids.", "Irrigate every 12–15 days during dry spells.", "Top-dress 40% Urea at 35 DAS."),
                StageGuidance("Flowering", "Days 61 – 100", "Square & flower initiation; install Pink Bollworm traps.", "Avoid drought stress to prevent square drop.", "Apply remaining N & K + 1% MgSO4 spray."),
                StageGuidance("Fruiting", "Days 101 – 140", "Boll formation & enlargement; spray 2% DAP or KNO3.", "Light frequent drip/furrow irrigation.", "Boron 0.1% spray supports healthy boll setting."),
                StageGuidance("Maturity", "Days 141 – 160", "Boll bursting phase; keep crop weed-free for clean lint.", "Stop irrigation once 30% bolls open.", "None."),
                StageGuidance("Harvested", "Days 160 – 180", "Pick dry clean kapas in 2–3 pickings; store separately by grade.", "Keep picked lint dry and trash-free.", "Remove stalks early to break pink bollworm cycle.")
            )
        ),
        CropGuide(
            cropType = "Soybean",
            hindiName = "Soyabean",
            season = "Kharif (Jun – Oct)",
            durationDays = 100,
            defaultVariety = "JS-9560",
            popularVarieties = listOf("JS-9560", "JS-335", "JS-20-34", "MACS-1188", "NRC-138"),
            idealSoil = "Well-drained black or loamy soil (pH 6.0 – 7.0)",
            idealTempRange = "22°C – 30°C",
            seedRatePerAcre = "28 – 32 kg / acre",
            spacing = "45 cm × 5 cm (BBF method recommended)",
            irrigationSchedule = "Mostly rainfed; give life-saving irrigation at flowering and pod-filling if monsoon breaks exceed 12 days.",
            fertilizerSchedule = "10 kg N + 25 kg P2O5 + 15 kg K2O + 8 kg Sulphur per acre at sowing (legume fixes its own Nitrogen).",
            pestManagement = "Treat seeds with Rhizobium + PSB + fungicide; monitor for Girdle Beetle, Semilooper, and Yellow Mosaic Virus.",
            harvestIndicators = "Leaves yellow and drop; 95% pods turn golden brown and seeds rattle inside.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Check germination (>75%); inoculate with Rhizobium & PSB.", "Use Broad Bed Furrow (BBF) for drainage.", "Apply single super phosphate for sulphur."),
                StageGuidance("Sowing", "Days 1 – 7", "Sow shallow (3 cm) after 75–100 mm soaking rain.", "Avoid crusting soil right after sowing.", "Full basal NPK + Sulphur at sowing."),
                StageGuidance("Germination", "Days 8 – 18", "Verify plant population; scout for stem fly.", "Drain standing rainwater immediately.", "None."),
                StageGuidance("Vegetative", "Days 19 – 42", "Keep weed-free for first 35 days; light hoeing.", "Protective irrigation only in long dry spell.", "Observe root nodules (pink = healthy N fixation)."),
                StageGuidance("Flowering", "Days 43 – 62", "Critical pod-set period; install bird perches & light traps.", "Irrigate if moisture stress occurs now.", "Foliar 19:19:19 (1%) boosts flower retention."),
                StageGuidance("Fruiting", "Days 63 – 85", "Pod filling; watch for Spodoptera caterpillars.", "Crucial irrigation window if rains recede early.", "0.5% Potassium spray improves seed size."),
                StageGuidance("Maturity", "Days 86 – 96", "Leaves shed naturally; avoid delayed harvest to prevent shattering.", "Stop watering.", "None."),
                StageGuidance("Harvested", "Days 96 – 105", "Harvest promptly when pods turn brown; thresh gently to avoid split seeds.", "Dry to 10–11% moisture.", "Store in cool dry room.")
            )
        ),
        CropGuide(
            cropType = "Sugarcane",
            hindiName = "Ganna",
            season = "Annual / Adsali (Oct – Mar planting)",
            durationDays = 330,
            defaultVariety = "Co-0238",
            popularVarieties = listOf("Co-0238", "Co-86032", "CoM-0265", "Co-0118", "CoLk-94184"),
            idealSoil = "Deep rich loamy soil with strong drainage (pH 6.5 – 7.5)",
            idealTempRange = "20°C – 35°C",
            seedRatePerAcre = "2.5 – 3 tonnes healthy 3-bud setts",
            spacing = "120 cm wide row (paired row for drip)",
            irrigationSchedule = "Frequent light irrigations every 7–10 days in summer and 15–20 days in winter; trash mulching preserves soil moisture.",
            fertilizerSchedule = "100 kg N + 45 kg P2O5 + 45 kg K2O per acre in 4 splits up to 120 DAP, plus micronutrients (Fe, Zn).",
            pestManagement = "Treat setts in hot water/fungicide against Red Rot; release Trichogramma cards for Early Shoot Borer.",
            harvestIndicators = "Canes produce metallic sound on tapping, Brix reading 18–20%, and arrows/top leaves dry slightly.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-planting", "Use disease-free 8–10 month seed cane; treat 2/3-bud setts.", "Prepare deep furrows 120 cm apart.", "Apply 10 tonnes FYM + basal Phosphorus."),
                StageGuidance("Sowing", "Days 1 – 15", "Plant setts horizontally in moist furrows and cover lightly.", "Irrigate immediately after planting.", "Apply 10% N + 50% P + 50% K."),
                StageGuidance("Germination", "Days 16 – 45", "Complete gap filling using polybag seedlings by 35 DAP.", "Light irrigation every 7 days.", "Trash mulch between rows to suppress weeds."),
                StageGuidance("Vegetative", "Days 46 – 130", "Tillering & light earthing up; scout for early shoot borer.", "Steady moisture; avoid cracking soil.", "Apply 40% N at 45 DAP and 40% N + rest P/K at 90 DAP."),
                StageGuidance("Flowering", "Days 131 – 220", "Grand growth phase; perform heavy earthing up & propping/tying.", "Highest water demand — irrigate every 7 days.", "Final 10% N + Potash + Micronutrients."),
                StageGuidance("Fruiting", "Days 221 – 290", "Cane elongation and sucrose accumulation; detrashe lower dry leaves.", "Reduce interval to 12–15 days.", "Avoid late Nitrogen (reduces sugar recovery)."),
                StageGuidance("Maturity", "Days 291 – 325", "Check Brix refractometer reading (>18%).", "Withhold irrigation 15 days before cutting.", "None."),
                StageGuidance("Harvested", "Days 325 – 340", "Cut flush to ground level; crush within 24 hours for peak sucrose.", "Keep stubble moist for ratoon crop.", "Shave stubble and apply basal dose for ratoon.")
            )
        ),
        CropGuide(
            cropType = "Maize",
            hindiName = "Makka",
            season = "Kharif & Rabi",
            durationDays = 105,
            defaultVariety = "DHM-117",
            popularVarieties = listOf("DHM-117", "HQPM-1", "P-3396", "NK-6240", "Bio-9681"),
            idealSoil = "Well-drained fertile sandy loam to silty loam (pH 5.8 – 7.5)",
            idealTempRange = "18°C – 32°C",
            seedRatePerAcre = "7 – 8 kg / acre",
            spacing = "60 cm × 20 cm on ridges",
            irrigationSchedule = "Never allow waterlogging; critical watering at Knee-High (30 DAS), Tasseling (50 DAS), Silking (60 DAS), and Grain Filling (75 DAS).",
            fertilizerSchedule = "50 kg N + 24 kg P2O5 + 16 kg K2O + 10 kg Zinc Sulphate per acre; split Nitrogen across basal, knee-high, and tasseling.",
            pestManagement = "Scout whorls weekly for Fall Armyworm (FAW); apply pheromone traps and neem/spinetoram targeted into whorls early.",
            harvestIndicators = "Cob husks dry to pale straw color and black layer forms at kernel base.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Choose high-yielding single-cross hybrid; treat seeds against downy mildew.", "Prepare raised ridges for drainage.", "Incorporate 4 tonnes compost/acre."),
                StageGuidance("Sowing", "Days 1 – 6", "Dibbling 1 seed per spot on ridge side at 4 cm depth.", "Light irrigation if soil lacks moisture.", "Basal 25% N + full P + K + Zinc."),
                StageGuidance("Germination", "Days 7 – 18", "Thin weak seedlings; keep 1 strong plant per hill.", "Ensure rainwater drains within 6 hours.", "Scout early for Fall Armyworm pinholes."),
                StageGuidance("Vegetative", "Days 19 – 45", "Knee-high stage; perform earthing up to prevent lodging.", "Critical knee-high irrigation at 28–32 DAS.", "Top-dress 50% Nitrogen along rows."),
                StageGuidance("Flowering", "Days 46 – 68", "Tasseling & silking — most water-sensitive stage!", "Irrigate reliably; moisture stress halves yield.", "Apply final 25% Nitrogen at pre-tasseling."),
                StageGuidance("Fruiting", "Days 69 – 90", "Blister, milk, and dough cob development.", "One good irrigation at grain filling.", "Protect cobs from birds and stem borer."),
                StageGuidance("Maturity", "Days 91 – 102", "Husks dry brown and kernels harden.", "Stop watering 10 days before harvest.", "None."),
                StageGuidance("Harvested", "Days 102 – 110", "Pick dry cobs, sun-dry, and shell when kernel moisture is <14%.", "Keep harvested cobs off bare damp ground.", "Store dry grain in hermetic bags.")
            )
        ),
        CropGuide(
            cropType = "Tomato",
            hindiName = "Tamatar",
            season = "All-Season (Rabi / Kharif / Summer)",
            durationDays = 110,
            defaultVariety = "Arka Rakshak",
            popularVarieties = listOf("Arka Rakshak", "Pusa Ruby", "Abhinav", "US-440", "Sahoo"),
            idealSoil = "Well-drained sandy loam rich in organic matter (pH 6.0 – 7.0)",
            idealTempRange = "20°C – 28°C",
            seedRatePerAcre = "120 – 150 g hybrid seed (nursery)",
            spacing = "90 cm × 45 cm on mulched raised beds",
            irrigationSchedule = "Drip irrigation daily or every 2 days; irregular watering during fruiting causes Blossom End Rot and fruit cracking.",
            fertilizerSchedule = "45 kg N + 30 kg P2O5 + 30 kg K2O per acre via fertigation; Calcium Nitrate & Boron sprays prevent fruit cracking.",
            pestManagement = "Use yellow sticky traps for Whitefly (Leaf Curl vector), pheromone traps for Fruit Borer, and preventive copper spray for Early Blight.",
            harvestIndicators = "Pick at breaker/pink stage for distant markets or firm red-ripe stage for local mandi.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Select triple-disease resistant F1 hybrids; raise in pro-trays with cocopeat.", "Fine mist watering twice daily in nursery.", "Drench nursery trays with Trichoderma."),
                StageGuidance("Sowing", "Days 1 – 25", "Transplant 25-day seedlings in cool evening onto silver-black mulched beds.", "Pre-wet beds 6 hours before transplanting.", "Basal compost + Neem cake + DAP."),
                StageGuidance("Germination", "Days 26 – 35", "Root establishment; replace any wilted plants within 5 days.", "Light daily drip (20 mins).", "Starter humic + 19:19:19 drench."),
                StageGuidance("Vegetative", "Days 36 – 52", "Install bamboo stakes & twine; prune suckers below first flower cluster.", "Consistent moderate drip moisture.", "Fertigate 19:19:19 + micronutrients."),
                StageGuidance("Flowering", "Days 53 – 70", "Flower truss setting; spray Boron 0.1% + Calcium Nitrate.", "Never over-water during peak bloom.", "Switch to 12:61:0 and 0:52:34 fertigation."),
                StageGuidance("Fruiting", "Days 71 – 95", "Fruit sizing; scout for fruit borer & blight after dew/rain.", "Uniform moisture prevents cracking & BER.", "Potassium-rich 0:0:50 + Calcium foliar feed."),
                StageGuidance("Maturity", "Days 96 – 105", "Fruits turn breaker/red; harvest every 3–4 days.", "Moderate morning drip only.", "Light K maintenance dose for next flush."),
                StageGuidance("Harvested", "Days 105 – 130", "Grade into plastic crates in shade for highest mandi price.", "Avoid harvesting wet fruits.", "Sanitize stakes & clear residues post-harvest.")
            )
        ),
        CropGuide(
            cropType = "Onion",
            hindiName = "Pyaaz",
            season = "Rabi (Best Storage) & Kharif",
            durationDays = 120,
            defaultVariety = "N-53 / Bhima Super",
            popularVarieties = listOf("Bhima Super", "N-53", "Agrifound Light Red", "Bhima Kiran", "Pusa Red"),
            idealSoil = "Friable sandy loam to silt loam, non-crusting (pH 6.0 – 7.0)",
            idealTempRange = "15°C – 28°C",
            seedRatePerAcre = "3 – 3.5 kg / acre (nursery)",
            spacing = "15 cm × 10 cm on flat or raised beds",
            irrigationSchedule = "Shallow roots need frequent light irrigation every 5–7 days; stop watering 15 days before harvest for better storage life.",
            fertilizerSchedule = "40 kg N + 20 kg P2O5 + 20 kg K2O + 15 kg Sulphur per acre (Sulphur improves pungency and shelf life).",
            pestManagement = "Blue sticky traps for Thrips; preventive Mancozeb/Azoxystrobin spray against Purple Blotch during foggy/humid weather.",
            harvestIndicators = "50–70% crop tops fall over naturally (neck fall) and outer skin turns dry papery red/pink.",
            stages = listOf(
                StageGuidance("Seed Selection", "Pre-sowing", "Use fresh (<1 yr old) certified seed; sow on raised nursery beds.", "Light rose-can irrigation in nursery.", "Mix vermicompost & Trichoderma in nursery."),
                StageGuidance("Sowing", "Days 1 – 45", "Transplant 45-day pencil-thick seedlings; dip roots in Carbendazim.", "Light irrigation immediately after planting.", "Basal 33% N + full P + K + Sulphur."),
                StageGuidance("Germination", "Days 46 – 58", "Seedling recovery; light hand weeding without disturbing bulbs.", "Irrigate every 4–5 days initially.", "None."),
                StageGuidance("Vegetative", "Days 59 – 80", "Leaf blade growth — more leaves mean bigger bulbs! Scout for Thrips.", "Irrigate every 6–7 days.", "Top-dress 33% Urea at 30 DAT + 33% at 45 DAT."),
                StageGuidance("Flowering", "Days 81 – 92", "Bulb initiation begins; snap off any premature flower stalks (bolters).", "Steady shallow watering; avoid drought.", "Stop Nitrogen after 50 DAT to prevent thick necks."),
                StageGuidance("Fruiting", "Days 93 – 110", "Rapid bulb swelling; spray 0:0:50 (1%) for firm dense bulbs.", "Light watering every 7 days.", "Potash + Sulphur boosts color & storage."),
                StageGuidance("Maturity", "Days 111 – 122", "50%+ tops fall over; stop irrigation completely.", "Zero irrigation 12–15 days pre-harvest.", "None."),
                StageGuidance("Harvested", "Days 122 – 130", "Pull bulbs gently, field-cure 3–5 days with leaves covering bulbs, trim 2 cm neck.", "Cure in shade before ventilated storage.", "Sort out doubles and bolters before storing.")
            )
        )
    )

    fun getGuide(cropType: String): CropGuide =
        allGuides.firstOrNull { it.cropType.equals(cropType, ignoreCase = true) } ?: allGuides.first()
}
