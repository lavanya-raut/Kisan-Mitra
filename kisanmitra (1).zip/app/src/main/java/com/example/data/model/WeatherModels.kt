package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class OpenMeteoResponse(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val timezone: String = "",
    val current: CurrentWeatherDto? = null,
    val hourly: HourlyWeatherDto? = null,
    val daily: DailyWeatherDto? = null
)

@JsonClass(generateAdapter = true)
data class CurrentWeatherDto(
    val time: String = "",
    @Json(name = "temperature_2m") val temperature2m: Double = 0.0,
    @Json(name = "relative_humidity_2m") val relativeHumidity2m: Int = 0,
    @Json(name = "apparent_temperature") val apparentTemperature: Double = 0.0,
    val precipitation: Double = 0.0,
    val rain: Double = 0.0,
    @Json(name = "weather_code") val weatherCode: Int = 0,
    @Json(name = "wind_speed_10m") val windSpeed10m: Double = 0.0,
    @Json(name = "soil_temperature_0cm") val soilTemperature0cm: Double? = null,
    @Json(name = "soil_moisture_0_to_1cm") val soilMoisture0To1cm: Double? = null
)

@JsonClass(generateAdapter = true)
data class HourlyWeatherDto(
    val time: List<String> = emptyList(),
    @Json(name = "temperature_2m") val temperature2m: List<Double> = emptyList(),
    @Json(name = "precipitation_probability") val precipitationProbability: List<Int> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int> = emptyList()
)

@JsonClass(generateAdapter = true)
data class DailyWeatherDto(
    val time: List<String> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int> = emptyList(),
    @Json(name = "temperature_2m_max") val temperature2mMax: List<Double> = emptyList(),
    @Json(name = "temperature_2m_min") val temperature2mMin: List<Double> = emptyList(),
    @Json(name = "precipitation_sum") val precipitationSum: List<Double> = emptyList(),
    @Json(name = "precipitation_probability_max") val precipitationProbabilityMax: List<Int> = emptyList(),
    @Json(name = "uv_index_max") val uvIndexMax: List<Double> = emptyList(),
    @Json(name = "wind_speed_10m_max") val windSpeed10mMax: List<Double> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GeocodingResponse(
    val results: List<GeocodingResultDto>? = null
)

@JsonClass(generateAdapter = true)
data class GeocodingResultDto(
    val id: Long = 0L,
    val name: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val admin1: String? = null,
    val country: String? = null
)

data class CityLocation(
    val name: String,
    val stateOrRegion: String,
    val latitude: Double,
    val longitude: Double
) {
    val displayLabel: String
        get() = if (stateOrRegion.isBlank()) name else "$name, $stateOrRegion"
}

data class HourlyForecastItem(
    val timeLabel: String,
    val temperatureC: Double,
    val rainChancePercent: Int,
    val weatherCode: Int
)

data class DailyForecastItem(
    val dateIso: String,
    val dayLabel: String,
    val weatherCode: Int,
    val conditionLabel: String,
    val maxTempC: Double,
    val minTempC: Double,
    val rainMm: Double,
    val rainChancePercent: Int,
    val uvIndexMax: Double,
    val maxWindKmh: Double
)

data class FarmWeatherAdvisory(
    val title: String,
    val summary: String,
    val sprayStatus: String,
    val irrigationTip: String,
    val isWarning: Boolean
)

data class WeatherSnapshot(
    val cityName: String,
    val latitude: Double,
    val longitude: Double,
    val temperatureC: Double,
    val feelsLikeC: Double,
    val humidityPercent: Int,
    val windSpeedKmh: Double,
    val precipitationMm: Double,
    val rainChanceTodayPercent: Int,
    val uvIndexToday: Double,
    val soilTemperatureC: Double?,
    val soilMoisture: Double?,
    val weatherCode: Int,
    val conditionLabel: String,
    val hourly: List<HourlyForecastItem>,
    val daily: List<DailyForecastItem>,
    val advisory: FarmWeatherAdvisory,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

object IndianAgriCities {
    val presets = listOf(
        CityLocation("Nagpur", "Maharashtra", 21.1458, 79.0882),
        CityLocation("Pune", "Maharashtra", 18.5204, 73.8567),
        CityLocation("Nashik", "Maharashtra", 19.9975, 73.7898),
        CityLocation("Ludhiana", "Punjab", 30.9010, 75.8573),
        CityLocation("Indore", "Madhya Pradesh", 22.7196, 75.8577),
        CityLocation("Varanasi", "Uttar Pradesh", 25.3176, 82.9739),
        CityLocation("Rajkot", "Gujarat", 22.3039, 70.8022),
        CityLocation("Jaipur", "Rajasthan", 26.9124, 75.7873),
        CityLocation("Hyderabad", "Telangana", 17.3850, 78.4867),
        CityLocation("Bengaluru", "Karnataka", 12.9716, 77.5946)
    )
}

object WeatherCodeMapper {
    fun describe(code: Int): String = when (code) {
        0 -> "Clear Sky"
        1 -> "Mainly Clear"
        2 -> "Partly Cloudy"
        3 -> "Overcast"
        45, 48 -> "Morning Fog"
        51, 53, 55 -> "Light Drizzle"
        56, 57 -> "Freezing Drizzle"
        61 -> "Light Rain"
        63 -> "Moderate Rain"
        65 -> "Heavy Rain"
        66, 67 -> "Freezing Rain"
        71, 73, 75, 77 -> "Snowfall"
        80, 81 -> "Rain Showers"
        82 -> "Heavy Showers"
        95 -> "Thunderstorm"
        96, 99 -> "Hail Thunderstorm"
        else -> "Partly Cloudy"
    }
}
