package com.example.data

import com.example.data.model.CityLocation
import com.example.data.model.DailyForecastItem
import com.example.data.model.FarmWeatherAdvisory
import com.example.data.model.GeocodingResponse
import com.example.data.model.HourlyForecastItem
import com.example.data.model.OpenMeteoResponse
import com.example.data.model.WeatherCodeMapper
import com.example.data.model.WeatherSnapshot
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

interface OpenMeteoForecastApi {
    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m,soil_temperature_0cm,soil_moisture_0_to_1cm",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,weather_code",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,uv_index_max,wind_speed_10m_max",
        @Query("timezone") timezone: String = "auto",
        @Query("forecast_days") forecastDays: Int = 7
    ): OpenMeteoResponse
}

interface OpenMeteoGeocodingApi {
    @GET("v1/search")
    suspend fun searchCities(
        @Query("name") query: String,
        @Query("count") count: Int = 8,
        @Query("language") language: String = "en",
        @Query("format") format: String = "json"
    ): GeocodingResponse
}

class WeatherRepository {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttp: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val forecastApi: OpenMeteoForecastApi = Retrofit.Builder()
        .baseUrl("https://api.open-meteo.com/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OpenMeteoForecastApi::class.java)

    private val geocodingApi: OpenMeteoGeocodingApi = Retrofit.Builder()
        .baseUrl("https://geocoding-api.open-meteo.com/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OpenMeteoGeocodingApi::class.java)

    suspend fun fetchWeather(
        cityName: String,
        latitude: Double,
        longitude: Double
    ): Result<WeatherSnapshot> {
        return try {
            val response = forecastApi.getForecast(latitude = latitude, longitude = longitude)
            val current = response.current ?: error("Weather data unavailable for $cityName")
            val dailyDto = response.daily
            val hourlyDto = response.hourly

            val currentIsoHour = current.time.take(13) // "YYYY-MM-DDTHH"
            val hourlyItems = mutableListOf<HourlyForecastItem>()
            if (hourlyDto != null && hourlyDto.time.isNotEmpty()) {
                val startIndex = hourlyDto.time.indexOfFirst { it.startsWith(currentIsoHour) }
                    .let { if (it >= 0) it else 0 }
                val endIndex = minOf(startIndex + 12, hourlyDto.time.size)
                for (i in startIndex until endIndex) {
                    val iso = hourlyDto.time[i]
                    val hourPart = iso.substringAfter("T", "00:00").take(5)
                    hourlyItems.add(
                        HourlyForecastItem(
                            timeLabel = formatHourLabel(hourPart),
                            temperatureC = hourlyDto.temperature2m.getOrElse(i) { current.temperature2m },
                            rainChancePercent = hourlyDto.precipitationProbability.getOrElse(i) { 0 },
                            weatherCode = hourlyDto.weatherCode.getOrElse(i) { current.weatherCode }
                        )
                    )
                }
            }

            val dailyItems = mutableListOf<DailyForecastItem>()
            if (dailyDto != null && dailyDto.time.isNotEmpty()) {
                for (i in dailyDto.time.indices) {
                    val isoDate = dailyDto.time[i]
                    val code = dailyDto.weatherCode.getOrElse(i) { 0 }
                    dailyItems.add(
                        DailyForecastItem(
                            dateIso = isoDate,
                            dayLabel = if (i == 0) "Today" else formatDayName(isoDate),
                            weatherCode = code,
                            conditionLabel = WeatherCodeMapper.describe(code),
                            maxTempC = dailyDto.temperature2mMax.getOrElse(i) { current.temperature2m },
                            minTempC = dailyDto.temperature2mMin.getOrElse(i) { current.temperature2m },
                            rainMm = dailyDto.precipitationSum.getOrElse(i) { 0.0 },
                            rainChancePercent = dailyDto.precipitationProbabilityMax.getOrElse(i) { 0 },
                            uvIndexMax = dailyDto.uvIndexMax.getOrElse(i) { 5.0 },
                            maxWindKmh = dailyDto.windSpeed10mMax.getOrElse(i) { current.windSpeed10m }
                        )
                    )
                }
            }

            val todayRainChance = dailyItems.firstOrNull()?.rainChancePercent ?: 0
            val todayUv = dailyItems.firstOrNull()?.uvIndexMax ?: 5.0
            val advisory = buildFarmAdvisory(
                tempC = current.temperature2m,
                humidity = current.relativeHumidity2m,
                windKmh = current.windSpeed10m,
                rainMm = current.precipitation,
                rainChance = todayRainChance
            )

            Result.success(
                WeatherSnapshot(
                    cityName = cityName,
                    latitude = response.latitude,
                    longitude = response.longitude,
                    temperatureC = current.temperature2m,
                    feelsLikeC = current.apparentTemperature,
                    humidityPercent = current.relativeHumidity2m,
                    windSpeedKmh = current.windSpeed10m,
                    precipitationMm = current.precipitation,
                    rainChanceTodayPercent = todayRainChance,
                    uvIndexToday = todayUv,
                    soilTemperatureC = current.soilTemperature0cm,
                    soilMoisture = current.soilMoisture0To1cm,
                    weatherCode = current.weatherCode,
                    conditionLabel = WeatherCodeMapper.describe(current.weatherCode),
                    hourly = hourlyItems,
                    daily = dailyItems,
                    advisory = advisory,
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun searchIndianCities(query: String): Result<List<CityLocation>> {
        val trimmed = query.trim()
        if (trimmed.length < 2) return Result.success(emptyList())
        return try {
            val response = geocodingApi.searchCities(query = trimmed)
            val list = response.results.orEmpty()
                .sortedByDescending { it.country.equals("India", ignoreCase = true) }
                .map { dto ->
                    val region = listOfNotNull(dto.admin1, dto.country)
                        .filter { it.isNotBlank() }
                        .joinToString(", ")
                    CityLocation(
                        name = dto.name,
                        stateOrRegion = region,
                        latitude = dto.latitude,
                        longitude = dto.longitude
                    )
                }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildFarmAdvisory(
        tempC: Double,
        humidity: Int,
        windKmh: Double,
        rainMm: Double,
        rainChance: Int
    ): FarmWeatherAdvisory {
        return when {
            rainMm >= 2.0 || rainChance >= 65 -> FarmWeatherAdvisory(
                title = "Rain Expected — Hold Spraying",
                summary = "High rain likelihood ($rainChance%). Postpone pesticide/foliar fertilizer application and open field drainage channels.",
                sprayStatus = "Not Recommended (Wash-off risk)",
                irrigationTip = "Skip scheduled irrigation today to conserve water and prevent root rot.",
                isWarning = true
            )
            windKmh >= 20.0 -> FarmWeatherAdvisory(
                title = "Gusty Winds (${windKmh.toInt()} km/h)",
                summary = "Strong winds can cause spray drift and lodge tall crops like Wheat, Maize, and Sugarcane.",
                sprayStatus = "Delay Spraying (Drift risk)",
                irrigationTip = "Prefer drip or furrow irrigation over overhead sprinklers today.",
                isWarning = true
            )
            tempC >= 37.0 -> FarmWeatherAdvisory(
                title = "High Heat Advisory (${tempC.toInt()}°C)",
                summary = "Elevated daytime heat increases evapotranspiration. Schedule field work and watering before 8 AM or after 5 PM.",
                sprayStatus = "Early Morning Only (Before 8 AM)",
                irrigationTip = "Give light evening irrigation to Tomato, Onion, and flowering crops.",
                isWarning = true
            )
            humidity >= 80 && tempC in 20.0..32.0 -> FarmWeatherAdvisory(
                title = "High Humidity — Fungal Watch",
                summary = "Warm humid air ($humidity%) favors early blight, rust, and mildew. Scout lower leaves closely.",
                sprayStatus = "Suitable if Dry Window Holds",
                irrigationTip = "Avoid evening overhead watering so leaves stay dry overnight.",
                isWarning = false
            )
            else -> FarmWeatherAdvisory(
                title = "Favorable Field Conditions",
                summary = "Calm winds (${windKmh.toInt()} km/h) and comfortable temperature (${tempC.toInt()}°C) make today ideal for routine crop care.",
                sprayStatus = "Good for Morning / Evening Spray",
                irrigationTip = "Follow your normal crop-stage irrigation schedule.",
                isWarning = false
            )
        }
    }

    private fun formatHourLabel(hhMm: String): String {
        val hour = hhMm.substringBefore(":").toIntOrNull() ?: return hhMm
        return when {
            hour == 0 -> "12 AM"
            hour < 12 -> "$hour AM"
            hour == 12 -> "12 PM"
            else -> "${hour - 12} PM"
        }
    }

    private fun formatDayName(isoDate: String): String {
        return try {
            val parser = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val formatter = SimpleDateFormat("EEE, d MMM", Locale.US)
            val parsed: Date = parser.parse(isoDate) ?: return isoDate
            formatter.format(parsed)
        } catch (_: Exception) {
            isoDate
        }
    }
}
