package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.KisanRepository
import com.example.data.WeatherRepository
import com.example.data.model.CityLocation
import com.example.data.model.FarmerProfile
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UiState
import com.example.data.model.UserCrop
import com.example.data.model.WeatherSnapshot
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KisanViewModel(
    private val repository: KisanRepository,
    private val weatherRepository: WeatherRepository,
    val currentUserId: String,
    initialDisplayName: String?,
    initialEmail: String?
) : ViewModel() {

    private val _weatherState = MutableStateFlow<UiState<WeatherSnapshot>>(UiState.Loading)
    val weatherState: StateFlow<UiState<WeatherSnapshot>> = _weatherState.asStateFlow()

    private val _citySearchState = MutableStateFlow<UiState<List<CityLocation>>>(UiState.Success(emptyList()))
    val citySearchState: StateFlow<UiState<List<CityLocation>>> = _citySearchState.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private var lastFetchedCoords: Pair<Double, Double>? = null

    val profileState: StateFlow<UiState<FarmerProfile?>> = repository.observeProfile(currentUserId)
        .asUiState("Failed to load farmer profile")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val cropsState: StateFlow<UiState<List<UserCrop>>> = repository.observeCrops(currentUserId)
        .asUiState("Failed to load crops")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val remindersState: StateFlow<UiState<List<FarmingReminder>>> = repository.observeReminders(currentUserId)
        .asUiState("Failed to load reminders")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val activitiesState: StateFlow<UiState<List<FarmingActivity>>> = repository.observeActivities(currentUserId)
        .asUiState("Failed to load activity history")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    init {
        viewModelScope.launch {
            repository.ensureProfileExists(currentUserId, initialDisplayName, initialEmail)
        }
        // Observe profile location changes to fetch live weather automatically
        viewModelScope.launch {
            profileState.collect { state ->
                if (state is UiState.Success && state.data != null) {
                    val p = state.data
                    val coords = p.latitude to p.longitude
                    if (lastFetchedCoords != coords) {
                        loadWeather(p.preferredCity, p.latitude, p.longitude)
                    }
                } else if (state is UiState.Success && state.data == null && lastFetchedCoords == null) {
                    loadWeather("Nagpur", 21.1458, 79.0882)
                }
            }
        }
    }

    private fun <T> Flow<T>.asUiState(fallbackError: String): Flow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, fallbackError, root)
                emit(UiState.Error(root.localizedMessage ?: fallbackError))
            }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    // --- WEATHER OPERATIONS ---

    fun loadWeather(cityName: String, latitude: Double, longitude: Double, forceRefresh: Boolean = false) {
        if (!forceRefresh && lastFetchedCoords == (latitude to longitude) && _weatherState.value is UiState.Success) {
            return
        }
        lastFetchedCoords = latitude to longitude
        viewModelScope.launch {
            _weatherState.value = UiState.Loading
            weatherRepository.fetchWeather(cityName, latitude, longitude)
                .onSuccess { snapshot ->
                    _weatherState.value = UiState.Success(snapshot)
                }
                .onFailure { err ->
                    _weatherState.value = UiState.Error(
                        err.localizedMessage ?: "Unable to fetch live weather. Check internet connection."
                    )
                }
        }
    }

    fun refreshWeather() {
        val currentProfile = (profileState.value as? UiState.Success)?.data
        val city = currentProfile?.preferredCity?.ifBlank { "Nagpur" } ?: "Nagpur"
        val lat = currentProfile?.latitude ?: 21.1458
        val lon = currentProfile?.longitude ?: 79.0882
        loadWeather(city, lat, lon, forceRefresh = true)
    }

    fun selectWeatherCity(location: CityLocation) {
        viewModelScope.launch {
            loadWeather(location.name, location.latitude, location.longitude, forceRefresh = true)
            repository.updateWeatherLocation(
                userId = currentUserId,
                cityName = location.name,
                latitude = location.latitude,
                longitude = location.longitude
            ).onSuccess {
                _actionMessage.value = "Weather location updated to ${location.name}"
            }
        }
    }

    fun searchCities(query: String) {
        viewModelScope.launch {
            if (query.trim().length < 2) {
                _citySearchState.value = UiState.Success(emptyList())
                return@launch
            }
            _citySearchState.value = UiState.Loading
            weatherRepository.searchIndianCities(query)
                .onSuccess { list -> _citySearchState.value = UiState.Success(list) }
                .onFailure { err ->
                    _citySearchState.value = UiState.Error(err.localizedMessage ?: "City search failed")
                }
        }
    }

    // --- PROFILE OPERATIONS ---

    fun saveFarmerProfile(profile: FarmerProfile, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.updateProfile(currentUserId, profile)
                .onSuccess {
                    _actionMessage.value = "Farmer profile saved"
                    onSaved()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to save profile"
                }
            _isSaving.value = false
        }
    }

    // --- CROP OPERATIONS ---

    fun addCrop(crop: UserCrop, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.addCrop(currentUserId, crop)
                .onSuccess {
                    _actionMessage.value = "${crop.cropType} added to My Crops"
                    onComplete()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to add crop"
                }
            _isSaving.value = false
        }
    }

    fun updateCrop(crop: UserCrop, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.updateCrop(currentUserId, crop)
                .onSuccess {
                    _actionMessage.value = "${crop.cropType} updated"
                    onComplete()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to update crop"
                }
            _isSaving.value = false
        }
    }

    fun updateCropGrowth(
        crop: UserCrop,
        stage: String,
        healthStatus: String,
        progressPercent: Int,
        notes: String
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.updateCropGrowth(
                userId = currentUserId,
                cropId = crop.id,
                stage = stage,
                healthStatus = healthStatus,
                progressPercent = progressPercent,
                notes = notes
            ).onSuccess {
                _actionMessage.value = "Growth updated to $stage ($progressPercent%)"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to update growth stage"
            }
            _isSaving.value = false
        }
    }

    fun deleteCrop(crop: UserCrop, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteCrop(currentUserId, crop.id)
                .onSuccess {
                    _actionMessage.value = "${crop.cropType} (${crop.plotName}) removed"
                    onComplete()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to delete crop"
                }
        }
    }

    // --- REMINDER OPERATIONS ---

    fun addReminder(reminder: FarmingReminder, onScheduled: (String) -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.addReminder(currentUserId, reminder)
                .onSuccess { newId ->
                    _actionMessage.value = "Reminder saved: ${reminder.title}"
                    onScheduled(newId)
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to save reminder"
                }
            _isSaving.value = false
        }
    }

    fun updateReminder(reminder: FarmingReminder, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.updateReminder(currentUserId, reminder)
                .onSuccess {
                    _actionMessage.value = "Reminder updated"
                    onComplete()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to update reminder"
                }
            _isSaving.value = false
        }
    }

    fun toggleReminder(reminder: FarmingReminder) {
        viewModelScope.launch {
            val nextState = !reminder.completed
            repository.toggleReminderCompleted(currentUserId, reminder.id, nextState)
                .onSuccess {
                    _actionMessage.value = if (nextState) "Marked completed" else "Marked pending"
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to update reminder"
                }
        }
    }

    fun deleteReminder(reminder: FarmingReminder) {
        viewModelScope.launch {
            repository.deleteReminder(currentUserId, reminder.id)
                .onSuccess { _actionMessage.value = "Reminder deleted" }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to delete reminder"
                }
        }
    }

    // --- ACTIVITY HISTORY OPERATIONS ---

    fun addActivity(activity: FarmingActivity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.addActivity(currentUserId, activity)
                .onSuccess {
                    _actionMessage.value = "Activity logged"
                    onComplete()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to log activity"
                }
            _isSaving.value = false
        }
    }

    fun updateActivity(activity: FarmingActivity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isSaving.value = true
            repository.updateActivity(currentUserId, activity)
                .onSuccess {
                    _actionMessage.value = "Activity updated"
                    onComplete()
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to update activity"
                }
            _isSaving.value = false
        }
    }

    fun deleteActivity(activity: FarmingActivity) {
        viewModelScope.launch {
            repository.deleteActivity(currentUserId, activity.id)
                .onSuccess { _actionMessage.value = "Activity deleted" }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Failed to delete activity"
                }
        }
    }

    private companion object {
        const val TAG = "KisanViewModel"
        const val STOP_TIMEOUT_MS = 5000L
    }
}
