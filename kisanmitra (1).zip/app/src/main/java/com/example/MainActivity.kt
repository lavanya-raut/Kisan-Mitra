package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.signOutFarmer
import com.example.data.KisanRepository
import com.example.data.WeatherRepository
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UiState
import com.example.data.model.UserCrop
import com.example.notifications.ReminderNotificationHelper
import com.example.ui.components.AddEditActivityDialog
import com.example.ui.components.AddEditCropDialog
import com.example.ui.components.AddEditReminderDialog
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarAndHistoryScreen
import com.example.ui.screens.CropDetailScreen
import com.example.ui.screens.CropGuidanceHubScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.MyCropsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.WeatherScreen
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.KisanMitraTheme
import com.example.ui.theme.PureWhite
import com.example.viewmodel.KisanViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ReminderNotificationHelper.ensureChannel(this)
        setContent {
            KisanMitraTheme {
                KisanMitraRoot()
            }
        }
    }
}

private enum class KisanTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME("Home", Icons.Rounded.Home, Icons.Outlined.Home, "nav_tab_home"),
    MY_CROPS("My Crops", Icons.Rounded.Eco, Icons.Outlined.Eco, "nav_tab_crops"),
    WEATHER("Weather", Icons.Rounded.Cloud, Icons.Outlined.Cloud, "nav_tab_weather"),
    CALENDAR("Calendar", Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_tab_calendar"),
    PROFILE("Profile", Icons.Rounded.Person, Icons.Outlined.Person, "nav_tab_profile")
}

@Composable
fun KisanMitraRoot() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            onAuthSuccess = { currentUser = Firebase.auth.currentUser }
        )
    } else {
        key(user.uid) {
            KisanMitraAuthenticatedApp(
                currentUserId = user.uid,
                displayName = user.displayName,
                email = user.email
            )
        }
    }
}

@Composable
private fun KisanMitraAuthenticatedApp(
    currentUserId: String,
    displayName: String?,
    email: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: KisanViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                KisanViewModel(
                    repository = KisanRepository(db),
                    weatherRepository = WeatherRepository(),
                    currentUserId = currentUserId,
                    initialDisplayName = displayName,
                    initialEmail = email
                )
            }
        }
    )

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val cropsState by viewModel.cropsState.collectAsStateWithLifecycle()
    val remindersState by viewModel.remindersState.collectAsStateWithLifecycle()
    val activitiesState by viewModel.activitiesState.collectAsStateWithLifecycle()
    val weatherState by viewModel.weatherState.collectAsStateWithLifecycle()
    val citySearchState by viewModel.citySearchState.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(actionMessage) {
        actionMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearActionMessage()
        }
    }

    var currentTab by remember { mutableStateOf(KisanTab.HOME) }
    var calendarInitialSubTab by remember { mutableIntStateOf(0) }
    var selectedCropId by remember { mutableStateOf<String?>(null) }
    var showGuidanceHub by remember { mutableStateOf(false) }

    // Modal dialogs state
    var showCropDialog by remember { mutableStateOf(false) }
    var editingCrop by remember { mutableStateOf<UserCrop?>(null) }
    var showReminderDialog by remember { mutableStateOf(false) }
    var editingReminder by remember { mutableStateOf<FarmingReminder?>(null) }
    var showActivityDialog by remember { mutableStateOf(false) }
    var editingActivity by remember { mutableStateOf<FarmingActivity?>(null) }
    var activityPreselectedCrop by remember { mutableStateOf<UserCrop?>(null) }

    val cropsList = (cropsState as? UiState.Success)?.data.orEmpty()
    val activitiesList = (activitiesState as? UiState.Success)?.data.orEmpty()
    val activeDetailCrop = selectedCropId?.let { id -> cropsList.firstOrNull { it.id == id } }

    val showBottomChrome = activeDetailCrop == null && !showGuidanceHub

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavRail && showBottomChrome) {
                NavigationRail(modifier = Modifier.fillMaxHeight()) {
                    KisanTab.entries.forEach { tab ->
                        val selected = currentTab == tab
                        NavigationRailItem(
                            selected = selected,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.label
                                )
                            },
                            label = { Text(tab.label) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useNavRail && showBottomChrome) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            KisanTab.entries.forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label, maxLines = 1) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                },
                floatingActionButton = {
                    if (showBottomChrome && currentTab == KisanTab.MY_CROPS) {
                        FloatingActionButton(
                            onClick = {
                                editingCrop = null
                                showCropDialog = true
                            },
                            containerColor = ForestGreen,
                            contentColor = PureWhite,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("fab_add_crop")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Add new crop")
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when {
                        showGuidanceHub -> {
                            CropGuidanceHubScreen(
                                initialCropType = activeDetailCrop?.cropType ?: "Wheat",
                                onBack = { showGuidanceHub = false }
                            )
                        }
                        activeDetailCrop != null -> {
                            CropDetailScreen(
                                crop = activeDetailCrop,
                                activities = activitiesList,
                                onBack = { selectedCropId = null },
                                onUpdateGrowth = { stage, health, progress, notes ->
                                    viewModel.updateCropGrowth(activeDetailCrop, stage, health, progress, notes)
                                },
                                onEditCrop = {
                                    editingCrop = activeDetailCrop
                                    showCropDialog = true
                                },
                                onLogActivityForCrop = {
                                    editingActivity = null
                                    activityPreselectedCrop = activeDetailCrop
                                    showActivityDialog = true
                                }
                            )
                        }
                        else -> when (currentTab) {
                            KisanTab.HOME -> HomeDashboardScreen(
                                profileState = profileState,
                                cropsState = cropsState,
                                remindersState = remindersState,
                                activitiesState = activitiesState,
                                weatherState = weatherState,
                                onOpenWeather = { currentTab = KisanTab.WEATHER },
                                onOpenMyCrops = { currentTab = KisanTab.MY_CROPS },
                                onOpenCropDetail = { crop -> selectedCropId = crop.id },
                                onOpenCropGuidanceHub = { showGuidanceHub = true },
                                onOpenCalendar = {
                                    calendarInitialSubTab = 1
                                    currentTab = KisanTab.CALENDAR
                                },
                                onOpenActivityHistory = {
                                    calendarInitialSubTab = 2
                                    currentTab = KisanTab.CALENDAR
                                },
                                onAddCropClick = {
                                    editingCrop = null
                                    showCropDialog = true
                                },
                                onAddReminderClick = {
                                    editingReminder = null
                                    showReminderDialog = true
                                },
                                onLogActivityClick = {
                                    editingActivity = null
                                    activityPreselectedCrop = null
                                    showActivityDialog = true
                                },
                                onToggleReminder = { viewModel.toggleReminder(it) },
                                onRetryWeather = { viewModel.refreshWeather() }
                            )

                            KisanTab.MY_CROPS -> MyCropsScreen(
                                cropsState = cropsState,
                                onAddCropClick = {
                                    editingCrop = null
                                    showCropDialog = true
                                },
                                onEditCropClick = { crop ->
                                    editingCrop = crop
                                    showCropDialog = true
                                },
                                onDeleteCrop = { crop -> viewModel.deleteCrop(crop) },
                                onSelectCrop = { crop -> selectedCropId = crop.id },
                                onOpenGuidanceHub = { showGuidanceHub = true }
                            )

                            KisanTab.WEATHER -> WeatherScreen(
                                weatherState = weatherState,
                                citySearchState = citySearchState,
                                onRefresh = { viewModel.refreshWeather() },
                                onSearchCityQuery = { viewModel.searchCities(it) },
                                onSelectCity = { viewModel.selectWeatherCity(it) }
                            )

                            KisanTab.CALENDAR -> CalendarAndHistoryScreen(
                                initialSubTab = calendarInitialSubTab,
                                remindersState = remindersState,
                                activitiesState = activitiesState,
                                onAddReminderClick = {
                                    editingReminder = null
                                    showReminderDialog = true
                                },
                                onEditReminderClick = { rem ->
                                    editingReminder = rem
                                    showReminderDialog = true
                                },
                                onToggleReminder = { viewModel.toggleReminder(it) },
                                onDeleteReminder = { rem ->
                                    ReminderNotificationHelper.cancelReminder(context, rem.id)
                                    viewModel.deleteReminder(rem)
                                },
                                onAddActivityClick = {
                                    editingActivity = null
                                    activityPreselectedCrop = null
                                    showActivityDialog = true
                                },
                                onEditActivityClick = { act ->
                                    editingActivity = act
                                    activityPreselectedCrop = null
                                    showActivityDialog = true
                                },
                                onDeleteActivity = { viewModel.deleteActivity(it) }
                            )

                            KisanTab.PROFILE -> ProfileScreen(
                                profileState = profileState,
                                cropsState = cropsState,
                                remindersState = remindersState,
                                activitiesState = activitiesState,
                                isSaving = isSaving,
                                onSaveProfile = { viewModel.saveFarmerProfile(it) },
                                onSignOut = {
                                    signOutFarmer(credentialManager = credentialManager, scope = scope)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // --- GLOBAL CRUD DIALOGS ---

    if (showCropDialog) {
        AddEditCropDialog(
            initialCrop = editingCrop,
            onDismiss = {
                showCropDialog = false
                editingCrop = null
            },
            onSave = { crop ->
                if (editingCrop == null) {
                    viewModel.addCrop(crop) { showCropDialog = false }
                } else {
                    viewModel.updateCrop(crop) {
                        showCropDialog = false
                        editingCrop = null
                    }
                }
            }
        )
    }

    if (showReminderDialog) {
        AddEditReminderDialog(
            crops = cropsList,
            initialReminder = editingReminder,
            onDismiss = {
                showReminderDialog = false
                editingReminder = null
            },
            onSave = { reminder ->
                if (editingReminder == null) {
                    viewModel.addReminder(reminder) { newId ->
                        ReminderNotificationHelper.scheduleReminder(
                            context = context,
                            reminderId = newId,
                            title = "KisanMitra: ${reminder.title}",
                            body = "${reminder.category} for ${reminder.cropName} (${reminder.timeLabel})",
                            triggerAtMillis = reminder.scheduledDateMillis
                        )
                        showReminderDialog = false
                    }
                } else {
                    viewModel.updateReminder(reminder) {
                        ReminderNotificationHelper.scheduleReminder(
                            context = context,
                            reminderId = reminder.id,
                            title = "KisanMitra: ${reminder.title}",
                            body = "${reminder.category} for ${reminder.cropName} (${reminder.timeLabel})",
                            triggerAtMillis = reminder.scheduledDateMillis
                        )
                        showReminderDialog = false
                        editingReminder = null
                    }
                }
            }
        )
    }

    if (showActivityDialog) {
        AddEditActivityDialog(
            crops = cropsList,
            preselectedCrop = activityPreselectedCrop,
            initialActivity = editingActivity,
            onDismiss = {
                showActivityDialog = false
                editingActivity = null
                activityPreselectedCrop = null
            },
            onSave = { activity ->
                if (editingActivity == null) {
                    viewModel.addActivity(activity) {
                        showActivityDialog = false
                        activityPreselectedCrop = null
                    }
                } else {
                    viewModel.updateActivity(activity) {
                        showActivityDialog = false
                        editingActivity = null
                    }
                }
            }
        )
    }
}
