package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.Grass
import androidx.compose.material.icons.rounded.LocalFlorist
import androidx.compose.material.icons.rounded.Opacity
import androidx.compose.material.icons.rounded.Park
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Thunderstorm
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbCloudy
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.AlertCrimsonContainer
import com.example.ui.theme.AmberCare
import com.example.ui.theme.AmberCareContainer
import com.example.ui.theme.DeepCanopyGreen
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.HarvestGold
import com.example.ui.theme.LeafGreen
import com.example.ui.theme.MeadowTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyWaterBlue
import com.example.ui.theme.SkyWaterContainer
import com.example.ui.theme.SproutGreen
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun KisanMitraLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(
                Brush.linearGradient(
                    colors = listOf(DeepCanopyGreen, ForestGreen, LeafGreen)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_kisanmitra_logo),
            contentDescription = "KisanMitra K Logo",
            modifier = Modifier.fillMaxSize().padding(size * 0.06f)
        )
    }
}

/**
 * Custom Compose Canvas editorial illustration of sunlit Indian green terraced farmland.
 */
@Composable
fun FarmHorizonBanner(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Deep forest-to-emerald sky gradient
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(DeepCanopyGreen, ForestGreen, LeafGreen),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )
        )

        // Warm sunrise glow in top-right
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    HarvestGold.copy(alpha = 0.42f),
                    HarvestGold.copy(alpha = 0.14f),
                    Color.Transparent
                ),
                center = Offset(w * 0.85f, h * 0.22f),
                radius = w * 0.42f
            ),
            radius = w * 0.42f,
            center = Offset(w * 0.85f, h * 0.22f)
        )

        // Crisp sun disc
        drawCircle(
            color = HarvestGold.copy(alpha = 0.88f),
            radius = h * 0.11f,
            center = Offset(w * 0.85f, h * 0.24f)
        )

        // Distant rolling hill
        val farHill = Path().apply {
            moveTo(0f, h * 0.72f)
            cubicTo(w * 0.25f, h * 0.50f, w * 0.55f, h * 0.68f, w, h * 0.56f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(farHill, color = SproutGreen.copy(alpha = 0.35f))

        // Foreground lush crop terrace
        val nearField = Path().apply {
            moveTo(0f, h * 0.80f)
            cubicTo(w * 0.30f, h * 0.68f, w * 0.68f, h * 0.88f, w, h * 0.72f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(nearField, color = Color(0xFF0E3E20).copy(alpha = 0.45f))

        // Subtle crop furrow contour lines
        for (i in 1..3) {
            val yOffset = h * (0.78f + i * 0.06f)
            drawLine(
                color = PureWhite.copy(alpha = 0.12f),
                start = Offset(w * 0.08f, yOffset),
                end = Offset(w * 0.92f, yOffset - h * 0.04f),
                strokeWidth = 2.5f
            )
        }
    }
}

@Composable
fun CropIconBadge(
    cropType: String,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    val (icon, bg, tint) = cropVisualTokens(cropType)
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = "$cropType icon",
            tint = tint,
            modifier = Modifier.size(size * 0.56f)
        )
    }
}

fun cropVisualTokens(cropType: String): Triple<ImageVector, Color, Color> = when (cropType) {
    "Wheat" -> Triple(Icons.Rounded.Grain, Color(0xFFFFF8E1), Color(0xFFBF7E00))
    "Rice" -> Triple(Icons.Rounded.Grass, Color(0xFFE8F5E9), ForestGreen)
    "Cotton" -> Triple(Icons.Rounded.Spa, Color(0xFFE3F2FD), Color(0xFF1565C0))
    "Soybean" -> Triple(Icons.Rounded.Eco, Color(0xFFF1F8E9), Color(0xFF33691E))
    "Sugarcane" -> Triple(Icons.Rounded.Park, Color(0xFFE0F2F1), Color(0xFF00695C))
    "Maize" -> Triple(Icons.Rounded.Agriculture, Color(0xFFFFF3E0), Color(0xFFE65100))
    "Tomato" -> Triple(Icons.Rounded.LocalFlorist, Color(0xFFFFEBEE), Color(0xFFC62828))
    "Onion" -> Triple(Icons.Rounded.Opacity, Color(0xFFF3E5F5), Color(0xFF6A1B9A))
    else -> Triple(Icons.Rounded.Eco, MeadowTint, ForestGreen)
}

@Composable
fun HealthStatusChip(status: String, modifier: Modifier = Modifier) {
    val (bg, fg) = when (status) {
        "Healthy" -> MeadowTint to ForestGreen
        "Needs Water" -> SkyWaterContainer to SkyWaterBlue
        "Pest Alert" -> AlertCrimsonContainer to AlertCrimson
        "Nutrient Care" -> AmberCareContainer to AmberCare
        else -> MeadowTint to ForestGreen
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = bg
    ) {
        Text(
            text = status,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun StageChip(stage: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
    ) {
        Text(
            text = stage,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

fun weatherCodeIcon(code: Int): ImageVector = when (code) {
    0, 1 -> Icons.Rounded.WbSunny
    2, 3 -> Icons.Rounded.WbCloudy
    45, 48 -> Icons.Rounded.Cloud
    51, 53, 55, 61, 63, 65, 80, 81, 82 -> Icons.Rounded.WaterDrop
    71, 73, 75, 77 -> Icons.Rounded.AcUnit
    95, 96, 99 -> Icons.Rounded.Thunderstorm
    else -> Icons.Rounded.WbCloudy
}

fun activityOrReminderIcon(type: String): ImageVector = when (type) {
    "Irrigation" -> Icons.Rounded.WaterDrop
    "Fertilizer" -> Icons.Rounded.Eco
    "Pest Control", "Pesticide" -> Icons.Rounded.BugReport
    "Sowing" -> Icons.Rounded.Grain
    "Harvesting", "Harvest" -> Icons.Rounded.Agriculture
    "Weeding" -> Icons.Rounded.Grass
    else -> Icons.Rounded.Spa
}

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    actionTestTag: String? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold
        )
        if (actionLabel != null && onActionClick != null) {
            TextButton(
                onClick = onActionClick,
                modifier = if (actionTestTag != null) Modifier.testTag(actionTestTag) else Modifier
            ) {
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    ctaLabel: String? = null,
    onCtaClick: (() -> Unit)? = null,
    ctaTestTag: String? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (ctaLabel != null && onCtaClick != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onCtaClick,
                    shape = RoundedCornerShape(14.dp),
                    modifier = if (ctaTestTag != null) Modifier.testTag(ctaTestTag) else Modifier
                ) {
                    Text(ctaLabel)
                }
            }
        }
    }
}

@Composable
fun KisanLoadingCard(
    message: String = "Loading...",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.5.dp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun KisanErrorCard(
    message: String,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AlertCrimsonContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.ErrorOutline,
                contentDescription = "Error",
                tint = AlertCrimson,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = AlertCrimson,
                modifier = Modifier.weight(1f)
            )
            if (onRetry != null) {
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onRetry) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Retry", tint = AlertCrimson)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Retry", color = AlertCrimson)
                }
            }
        }
    }
}

object FarmDateUtils {
    private val shortFormatter = SimpleDateFormat("d MMM yyyy", Locale.US)
    private val dayMonthFormatter = SimpleDateFormat("d MMM", Locale.US)

    fun formatDate(millis: Long): String {
        if (millis <= 0L) return "Not set"
        return shortFormatter.format(Date(millis))
    }

    fun formatShortDay(millis: Long): String {
        if (millis <= 0L) return "Today"
        return dayMonthFormatter.format(Date(millis))
    }

    fun daysSince(millis: Long): Int {
        if (millis <= 0L) return 0
        val diff = System.currentTimeMillis() - millis
        return (diff / 86_400_000L).toInt().coerceAtLeast(0)
    }

    fun isSameDay(millisA: Long, millisB: Long): Boolean {
        val calA = Calendar.getInstance().apply { timeInMillis = millisA }
        val calB = Calendar.getInstance().apply { timeInMillis = millisB }
        return calA.get(Calendar.YEAR) == calB.get(Calendar.YEAR) &&
            calA.get(Calendar.DAY_OF_YEAR) == calB.get(Calendar.DAY_OF_YEAR)
    }

    fun startOfTodayMillis(): Long {
        return Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun dayMillisOffset(daysFromToday: Int): Long {
        return Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, daysFromToday)
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}
