package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CropGuidanceCatalog
import com.example.data.model.FarmConstants
import com.example.data.model.FarmingActivity
import com.example.data.model.UiState
import com.example.data.model.UserCrop
import com.example.ui.components.CropIconBadge
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FarmDateUtils
import com.example.ui.components.HealthStatusChip
import com.example.ui.components.KisanErrorCard
import com.example.ui.components.KisanLoadingCard
import com.example.ui.components.StageChip
import com.example.ui.components.activityOrReminderIcon
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.MeadowTint

@Composable
fun MyCropsScreen(
    cropsState: UiState<List<UserCrop>>,
    onAddCropClick: () -> Unit,
    onEditCropClick: (UserCrop) -> Unit,
    onDeleteCrop: (UserCrop) -> Unit,
    onSelectCrop: (UserCrop) -> Unit,
    onOpenGuidanceHub: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("All") }
    var cropPendingDelete by remember { mutableStateOf<UserCrop?>(null) }

    val filterOptions = listOf("All") + FarmConstants.SUPPORTED_CROPS

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "My Crops",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Track lifecycle from seed selection to harvest",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = onOpenGuidanceHub,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("crops_open_guide_btn")
            ) {
                Icon(Icons.Rounded.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Guides")
            }
        }

        // Crop Type Filter Strip
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filterOptions) { option ->
                FilterChip(
                    selected = selectedFilter == option,
                    onClick = { selectedFilter = option },
                    label = { Text(option) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (cropsState) {
            is UiState.Loading -> Box(Modifier.padding(16.dp)) {
                KisanLoadingCard("Loading your crops...")
            }
            is UiState.Error -> Box(Modifier.padding(16.dp)) {
                KisanErrorCard(cropsState.message)
            }
            is UiState.Success -> {
                val allCrops = cropsState.data
                val filtered = if (selectedFilter == "All") {
                    allCrops
                } else {
                    allCrops.filter { it.cropType == selectedFilter }
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.padding(16.dp)) {
                        EmptyStateCard(
                            icon = Icons.Rounded.Eco,
                            title = if (selectedFilter == "All") "Start Tracking Your Crops" else "No $selectedFilter Plots Yet",
                            subtitle = "Supported crops: Wheat, Rice, Cotton, Soybean, Sugarcane, Maize, Tomato, and Onion.",
                            ctaLabel = "Add Crop",
                            onCtaClick = onAddCropClick,
                            ctaTestTag = "my_crops_empty_add_btn"
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 92.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filtered, key = { it.id }) { crop ->
                            CropListCard(
                                crop = crop,
                                onClick = { onSelectCrop(crop) },
                                onEdit = { onEditCropClick(crop) },
                                onDelete = { cropPendingDelete = crop }
                            )
                        }
                    }
                }
            }
        }
    }

    if (cropPendingDelete != null) {
        val target = cropPendingDelete!!
        AlertDialog(
            onDismissRequest = { cropPendingDelete = null },
            title = { Text("Delete ${target.cropType}?") },
            text = { Text("Remove ${target.cropType} (${target.plotName}) from your active crops?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCrop(target)
                        cropPendingDelete = null
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { cropPendingDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CropListCard(
    crop: UserCrop,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val daysElapsed = FarmDateUtils.daysSince(crop.sowingDateMillis)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("crop_card_${crop.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CropIconBadge(cropType = crop.cropType, size = 48.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = crop.cropType,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        HealthStatusChip(status = crop.healthStatus)
                    }
                    Text(
                        text = "${crop.plotName} · ${crop.variety} · ${crop.areaAcres} ac",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onEdit, modifier = Modifier.testTag("edit_crop_${crop.id}")) {
                    Icon(Icons.Rounded.Edit, contentDescription = "Edit crop", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_crop_${crop.id}")) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete crop", tint = AlertCrimson)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StageChip(stage = crop.currentStage)
                Text(
                    text = "Day $daysElapsed · ${crop.progressPercent}% complete",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { crop.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(50)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Sown: ${FarmDateUtils.formatDate(crop.sowingDateMillis)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Est. Harvest: ${FarmDateUtils.formatDate(crop.expectedHarvestMillis)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CropDetailScreen(
    crop: UserCrop,
    activities: List<FarmingActivity>,
    onBack: () -> Unit,
    onUpdateGrowth: (stage: String, health: String, progress: Int, notes: String) -> Unit,
    onEditCrop: () -> Unit,
    onLogActivityForCrop: () -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedTab by remember { mutableIntStateOf(0) }
    var stage by remember(crop.id, crop.currentStage) { mutableStateOf(crop.currentStage) }
    var health by remember(crop.id, crop.healthStatus) { mutableStateOf(crop.healthStatus) }
    var progress by remember(crop.id, crop.progressPercent) { mutableFloatStateOf(crop.progressPercent.toFloat()) }
    var notes by remember(crop.id, crop.notes) { mutableStateOf(crop.notes) }

    val guide = remember(crop.cropType) { CropGuidanceCatalog.getGuide(crop.cropType) }
    val cropActivities = remember(activities, crop.id, crop.cropType) {
        activities.filter { it.cropId == crop.id || it.cropName.equals(crop.cropType, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("crop_detail_back_btn")) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to My Crops")
            }
            CropIconBadge(cropType = crop.cropType, size = 38.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${crop.cropType} (${crop.plotName})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${crop.variety} · ${crop.areaAcres} acres · Day ${FarmDateUtils.daysSince(crop.sowingDateMillis)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onEditCrop) {
                Icon(Icons.Rounded.Edit, contentDescription = "Edit crop details", tint = MaterialTheme.colorScheme.primary)
            }
        }

        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Growth Tracker") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Crop Guide") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("History (${cropActivities.size})") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // Interactive Growth Tracker Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Update Crop Growth Stage",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FarmConstants.CROP_STAGES.forEach { st ->
                                        FilterChip(
                                            selected = stage == st,
                                            onClick = {
                                                stage = st
                                                progress = FarmConstants.defaultProgressForStage(st).toFloat()
                                            },
                                            label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }

                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Lifecycle Completion", style = MaterialTheme.typography.labelLarge)
                                        Text(
                                            "${progress.toInt()}%",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Slider(
                                        value = progress,
                                        onValueChange = { progress = it },
                                        valueRange = 0f..100f
                                    )
                                }

                                Text("Field Health Status", style = MaterialTheme.typography.labelLarge)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FarmConstants.HEALTH_STATUSES.forEach { statusOption ->
                                        FilterChip(
                                            selected = health == statusOption,
                                            onClick = { health = statusOption },
                                            label = { Text(statusOption, style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }

                                OutlinedTextField(
                                    value = notes,
                                    onValueChange = { notes = it },
                                    label = { Text("Growth Observation Notes") },
                                    maxLines = 3,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = { onUpdateGrowth(stage, health, progress.toInt(), notes) },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("save_growth_update_btn")
                                ) {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Save Growth Progress")
                                }
                            }
                        }
                    }

                    // Stage-Specific Advice for Current Stage
                    item {
                        val currentStageTip = guide.stages.firstOrNull { it.stageName == stage } ?: guide.stages.first()
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MeadowTint)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Recommended Actions for $stage (${currentStageTip.dayRange})",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ForestGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("• Action: ${currentStageTip.keyActions}", style = MaterialTheme.typography.bodyMedium)
                                Text("• Water: ${currentStageTip.waterTip}", style = MaterialTheme.typography.bodyMedium)
                                Text("• Nutrition: ${currentStageTip.nutrientTip}", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                1 -> {
                    item {
                        CropGuideDetailCards(guide = guide)
                    }
                }

                2 -> {
                    item {
                        Button(
                            onClick = onLogActivityForCrop,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().testTag("crop_detail_log_activity_btn")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Log Activity for ${crop.cropType}")
                        }
                    }
                    if (cropActivities.isEmpty()) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Rounded.WaterDrop,
                                title = "No Activities Recorded",
                                subtitle = "Log irrigation, fertilizer, pesticide, or harvest records for ${crop.cropType}."
                            )
                        }
                    } else {
                        items(cropActivities, key = { it.id }) { act ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(MeadowTint),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(activityOrReminderIcon(act.activityType), contentDescription = null, tint = ForestGreen)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(act.title, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            "${act.activityType} · ${FarmDateUtils.formatDate(act.activityDateMillis)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (act.notes.isNotBlank()) {
                                            Text(act.notes, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                    if (act.costInr > 0) {
                                        Surface(shape = RoundedCornerShape(50), color = MeadowTint) {
                                            Text(
                                                "₹${act.costInr.toInt()}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = ForestGreen,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
