package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val KisanLightColorScheme = lightColorScheme(
    primary = ForestGreen,
    onPrimary = PureWhite,
    primaryContainer = MeadowTint,
    onPrimaryContainer = DeepCanopyGreen,
    secondary = LeafGreen,
    onSecondary = PureWhite,
    secondaryContainer = SoftSage,
    onSecondaryContainer = DeepCanopyGreen,
    tertiary = HarvestGold,
    onTertiary = PureWhite,
    tertiaryContainer = HarvestGoldContainer,
    onTertiaryContainer = DeepSlateInk,
    background = DewSurface,
    onBackground = DeepSlateInk,
    surface = PureWhite,
    onSurface = DeepSlateInk,
    surfaceVariant = MeadowTint,
    onSurfaceVariant = MutedSageText,
    outline = SoftOutline,
    outlineVariant = ColorTokens.SubtleDivider,
    error = AlertCrimson,
    onError = PureWhite,
    errorContainer = AlertCrimsonContainer,
    onErrorContainer = AlertCrimson
)

private val KisanDarkColorScheme = darkColorScheme(
    primary = DarkPrimaryGreen,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = SproutGreen,
    onSecondary = PureWhite,
    secondaryContainer = ColorTokens.DarkSecondaryContainer,
    onSecondaryContainer = SoftSage,
    tertiary = HarvestGold,
    onTertiary = DeepSlateInk,
    tertiaryContainer = ColorTokens.DarkGoldContainer,
    onTertiaryContainer = HarvestGoldContainer,
    background = DarkSurface,
    onBackground = ColorTokens.DarkOnSurface,
    surface = DarkSurfaceContainer,
    onSurface = ColorTokens.DarkOnSurface,
    surfaceVariant = ColorTokens.DarkSurfaceVariant,
    onSurfaceVariant = ColorTokens.DarkMutedText,
    outline = DarkOutline,
    error = ColorTokens.DarkError,
    onError = DeepSlateInk
)

private object ColorTokens {
    val SubtleDivider = androidx.compose.ui.graphics.Color(0xFFE3EEE4)
    val DarkSecondaryContainer = androidx.compose.ui.graphics.Color(0xFF1F3823)
    val DarkGoldContainer = androidx.compose.ui.graphics.Color(0xFF42320A)
    val DarkOnSurface = androidx.compose.ui.graphics.Color(0xFFEBF4EC)
    val DarkSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF223125)
    val DarkMutedText = androidx.compose.ui.graphics.Color(0xFFA9C0AD)
    val DarkError = androidx.compose.ui.graphics.Color(0xFFEF9A9A)
}

val KisanShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun KisanMitraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) KisanDarkColorScheme else KisanLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = KisanMitraTypography,
        shapes = KisanShapes,
        content = content
    )
}
