package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.model.CityLocation
import com.example.data.model.DailyForecastItem
import com.example.data.model.HourlyForecastItem
import com.example.data.model.IndianAgriCities
import com.example.data.model.UiState
import com.example.data.model.WeatherSnapshot
import com.example.ui.components.KisanErrorCard
import com.example.ui.components.KisanLoadingCard
import com.example.ui.components.weatherCodeIcon
import com.example.ui.theme.AmberCare
import com.example.ui.theme.AmberCareContainer
import com.example.ui.theme.DeepCanopyGreen
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.LeafGreen
import com.example.ui.theme.MeadowTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyWaterBlue
import com.google.android.gms.location.LocationServices
import kotlin.math.roundToInt

@Composable
fun WeatherScreen(
    weatherState: UiState<WeatherSnapshot>,
    citySearchState: UiState<List<CityLocation>>,
    onRefresh: () -> Unit,
    onSearchCityQuery: (String) -> Unit,
    onSelectCity: (CityLocation) -> Unit
) {
    val context = LocalContext.current
    var showCityDialog by remember { mutableStateOf(false) }
    var locationNotice by remember { mutableStateOf<String?>(null) }

    @SuppressLint("MissingPermission")
    fun requestDeviceGpsLocation() {
        val client = LocationServices.getFusedLocationProviderClient(context)
        client.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    locationNotice = null
                    onSelectCity(
                        CityLocation(
                            name = "My Farm (GPS)",
                            stateOrRegion = "${String.format("%.2f", location.latitude)}°N, ${String.format("%.2f", location.longitude)}°E",
                            latitude = location.latitude,
                            longitude = location.longitude
                        )
                    )
                } else {
                    locationNotice = "GPS location unavailable right now. Choose your district below."
                }
            }
            .addOnFailureListener {
                locationNotice = "Could not read GPS location. Select a city manually."
            }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            requestDeviceGpsLocation()
        } else {
            locationNotice = "Location permission declined. You can search any Indian town or city."
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header + Location Controls
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weather Updates",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Live agricultural forecast via Open-Meteo",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalIconButton(
                        onClick = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                requestDeviceGpsLocation()
                            } else {
                                locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                            }
                        },
                        modifier = Modifier.testTag("weather_gps_btn")
                    ) {
                        Icon(Icons.Rounded.MyLocation, contentDescription = "Use device GPS location")
                    }
                    FilledTonalIconButton(
                        onClick = { showCityDialog = true },
                        modifier = Modifier.testTag("weather_search_city_btn")
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = "Search Indian city")
                    }
                    FilledTonalIconButton(
                        onClick = onRefresh,
                        modifier = Modifier.testTag("weather_refresh_btn")
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Refresh live weather")
                    }
                }
            }
        }

        if (locationNotice != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = AmberCareContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = locationNotice!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberCare,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        when (weatherState) {
            is UiState.Loading -> {
                item { KisanLoadingCard("Loading live Open-Meteo weather data...") }
            }
            is UiState.Error -> {
                item { KisanErrorCard(message = weatherState.message, onRetry = onRefresh) }
            }
            is UiState.Success -> {
                val weather = weatherState.data

                // Hero Current Conditions Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        listOf(DeepCanopyGreen, ForestGreen, LeafGreen)
                                    )
                                )
                                .padding(20.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.clickable { showCityDialog = true },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = PureWhite, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = weather.cityName,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = PureWhite
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = PureWhite.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = weather.conditionLabel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = PureWhite,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "${weather.temperatureC.roundToInt()}°C",
                                            style = MaterialTheme.typography.displayLarge,
                                            color = PureWhite
                                        )
                                        Text(
                                            text = "Feels like ${weather.feelsLikeC.roundToInt()}°C · Rain Chance ${weather.rainChanceTodayPercent}%",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = PureWhite.copy(alpha = 0.9f)
                                        )
                                    }
                                    Icon(
                                        imageVector = weatherCodeIcon(weather.weatherCode),
                                        contentDescription = weather.conditionLabel,
                                        tint = PureWhite,
                                        modifier = Modifier.size(64.dp)
                                    )
                                }

                                // 4 Key Agro-Metrics
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    HeroMetricChip(Icons.Rounded.WaterDrop, "Humidity", "${weather.humidityPercent}%")
                                    HeroMetricChip(Icons.Rounded.Air, "Wind", "${weather.windSpeedKmh.roundToInt()} km/h")
                                    HeroMetricChip(Icons.Rounded.WbSunny, "UV Max", "${weather.uvIndexToday.roundToInt()}")
                                    HeroMetricChip(
                                        Icons.Rounded.Thermostat,
                                        "Soil",
                                        weather.soilTemperatureC?.let { "${it.roundToInt()}°C" } ?: "--"
                                    )
                                }
                            }
                        }
                    }
                }

                // Farm Spray & Irrigation Advisory Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (weather.advisory.isWarning) AmberCareContainer else MeadowTint
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Farm Advisory: ${weather.advisory.title}",
                                style = MaterialTheme.typography.titleMedium,
                                color = if (weather.advisory.isWarning) AmberCare else ForestGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = weather.advisory.summary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "• Spraying: ${weather.advisory.sprayStatus}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "• Irrigation: ${weather.advisory.irrigationTip}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Hourly Forecast
                if (weather.hourly.isNotEmpty()) {
                    item {
                        Text(
                            text = "Next 12 Hours",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(weather.hourly) { hour ->
                                HourlyCard(hour)
                            }
                        }
                    }
                }

                // 7-Day Forecast
                if (weather.daily.isNotEmpty()) {
                    item {
                        Text(
                            text = "7-Day Agricultural Forecast",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                        ) {
                            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                weather.daily.forEachIndexed { idx, day ->
                                    DailyForecastRow(day)
                                    if (idx < weather.daily.lastIndex) {
                                        HorizontalDivider(
                                            modifier = Modifier.padding(horizontal = 16.dp),
                                            color = MaterialTheme.colorScheme.outlineVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick City Switcher CTA
                item {
                    OutlinedButton(
                        onClick = { showCityDialog = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Change Village / District Location")
                    }
                }
            }
        }
    }

    if (showCityDialog) {
        CitySearchDialog(
            searchState = citySearchState,
            onQueryChange = onSearchCityQuery,
            onSelect = { loc ->
                onSelectCity(loc)
                showCityDialog = false
            },
            onDismiss = { showCityDialog = false }
        )
    }
}

@Composable
private fun HeroMetricChip(icon: ImageVector, label: String, value: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(PureWhite.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Icon(icon, contentDescription = label, tint = PureWhite, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.labelLarge, color = PureWhite, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = PureWhite.copy(alpha = 0.8f))
    }
}

@Composable
private fun HourlyCard(item: HourlyForecastItem) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(item.timeLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Icon(
                imageVector = weatherCodeIcon(item.weatherCode),
                contentDescription = null,
                tint = ForestGreen,
                modifier = Modifier.size(22.dp)
            )
            Text("${item.temperatureC.roundToInt()}°", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("${item.rainChancePercent}%", style = MaterialTheme.typography.labelSmall, color = SkyWaterBlue)
        }
    }
}

@Composable
private fun DailyForecastRow(item: DailyForecastItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1.2f)) {
            Text(item.dayLabel, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(item.conditionLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(
            modifier = Modifier.weight(0.9f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(weatherCodeIcon(item.weatherCode), contentDescription = null, tint = ForestGreen, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("${item.rainChancePercent}%", style = MaterialTheme.typography.labelMedium, color = SkyWaterBlue)
        }
        Text(
            text = "${item.maxTempC.roundToInt()}° / ${item.minTempC.roundToInt()}°",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun CitySearchDialog(
    searchState: UiState<List<CityLocation>>,
    onQueryChange: (String) -> Unit,
    onSelect: (CityLocation) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Select Farm Location", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onQueryChange(it)
                    },
                    label = { Text("Search Indian City / Town") },
                    placeholder = { Text("e.g. Nashik, Wardha, Ludhiana") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("city_search_input")
                )

                val itemsToShow: List<CityLocation> = if (query.trim().length >= 2) {
                    when (searchState) {
                        is UiState.Success -> searchState.data
                        else -> emptyList()
                    }
                } else {
                    IndianAgriCities.presets
                }

                if (query.trim().length >= 2 && searchState is UiState.Loading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Searching cities...", style = MaterialTheme.typography.bodySmall)
                    }
                } else if (itemsToShow.isEmpty()) {
                    Text("No matching cities found.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(itemsToShow) { city ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelect(city) }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(city.name, style = MaterialTheme.typography.titleSmall)
                                    Text(city.stateOrRegion, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
