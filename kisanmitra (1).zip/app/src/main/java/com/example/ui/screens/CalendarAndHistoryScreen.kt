package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UiState
import com.example.notifications.ReminderNotificationHelper
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FarmDateUtils
import com.example.ui.components.KisanErrorCard
import com.example.ui.components.KisanLoadingCard
import com.example.ui.components.activityOrReminderIcon
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.HarvestGold
import com.example.ui.theme.MeadowTint
import com.example.ui.theme.PureWhite
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarAndHistoryScreen(
    initialSubTab: Int = 0,
    remindersState: UiState<List<FarmingReminder>>,
    activitiesState: UiState<List<FarmingActivity>>,
    onAddReminderClick: () -> Unit,
    onEditReminderClick: (FarmingReminder) -> Unit,
    onToggleReminder: (FarmingReminder) -> Unit,
    onDeleteReminder: (FarmingReminder) -> Unit,
    onAddActivityClick: () -> Unit,
    onEditActivityClick: (FarmingActivity) -> Unit,
    onDeleteActivity: (FarmingActivity) -> Unit
) {
    val context = LocalContext.current
    var selectedSubTab by remember(initialSubTab) { mutableIntStateOf(initialSubTab) }
    var notificationsEnabled by remember {
        mutableStateOf(ReminderNotificationHelper.hasNotificationPermission(context))
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsEnabled = granted
        if (granted) {
            ReminderNotificationHelper.showNotificationNow(
                context = context,
                notificationId = 9001,
                title = "KisanMitra Alerts Active",
                body = "You will now receive timely reminders for irrigation, fertilizers, and crop care."
            )
        }
    }

    val reminders = (remindersState as? UiState.Success)?.data.orEmpty()
    val activities = (activitiesState as? UiState.Success)?.data.orEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Farming Calendar",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Schedules, reminders & field activity history",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!notificationsEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                OutlinedButton(
                    onClick = { notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("enable_notifications_btn")
                ) {
                    Icon(Icons.Rounded.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Alerts")
                }
            }
        }

        TabRow(selectedTabIndex = selectedSubTab) {
            Tab(selected = selectedSubTab == 0, onClick = { selectedSubTab = 0 }, text = { Text("Calendar") })
            Tab(selected = selectedSubTab == 1, onClick = { selectedSubTab = 1 }, text = { Text("Reminders (${reminders.count { !it.completed }})") })
            Tab(selected = selectedSubTab == 2, onClick = { selectedSubTab = 2 }, text = { Text("History (${activities.size})") })
        }

        when (selectedSubTab) {
            0 -> MonthlyCalendarTab(
                reminders = reminders,
                activities = activities,
                onAddReminderClick = onAddReminderClick,
                onAddActivityClick = onAddActivityClick,
                onToggleReminder = onToggleReminder
            )
            1 -> RemindersTab(
                remindersState = remindersState,
                onAddReminderClick = onAddReminderClick,
                onEditReminderClick = onEditReminderClick,
                onToggleReminder = onToggleReminder,
                onDeleteReminder = onDeleteReminder
            )
            2 -> ActivityHistoryTab(
                activitiesState = activitiesState,
                onAddActivityClick = onAddActivityClick,
                onEditActivityClick = onEditActivityClick,
                onDeleteActivity = onDeleteActivity
            )
        }
    }
}

@Composable
private fun MonthlyCalendarTab(
    reminders: List<FarmingReminder>,
    activities: List<FarmingActivity>,
    onAddReminderClick: () -> Unit,
    onAddActivityClick: () -> Unit,
    onToggleReminder: (FarmingReminder) -> Unit
) {
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDateMillis by remember { mutableLongStateOf(FarmDateUtils.startOfTodayMillis()) }

    val displayCal = remember(monthOffset) {
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MONTH, monthOffset)
        }
    }

    val monthLabel = remember(monthOffset) {
        SimpleDateFormat("MMMM yyyy", Locale.US).format(displayCal.time)
    }

    val daysInMonth = displayCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeekOffset = displayCal.get(Calendar.DAY_OF_WEEK) - 1 // Sunday = 0

    val selectedDayReminders = reminders.filter { FarmDateUtils.isSameDay(it.scheduledDateMillis, selectedDateMillis) }
    val selectedDayActivities = activities.filter { FarmDateUtils.isSameDay(it.activityDateMillis, selectedDateMillis) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { monthOffset -= 1 }) {
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous month")
                        }
                        Text(monthLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { monthOffset += 1 }) {
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next month")
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").forEach { d ->
                            Text(
                                text = d,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    val totalCells = firstDayOfWeekOffset + daysInMonth
                    val rows = (totalCells + 6) / 7
                    for (r in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (c in 0 until 7) {
                                val cellIndex = r * 7 + c
                                val dayNum = cellIndex - firstDayOfWeekOffset + 1
                                if (dayNum in 1..daysInMonth) {
                                    val cellMillis = (displayCal.clone() as Calendar).apply {
                                        set(Calendar.DAY_OF_MONTH, dayNum)
                                    }.timeInMillis
                                    val isSelected = FarmDateUtils.isSameDay(cellMillis, selectedDateMillis)
                                    val hasRem = reminders.any { FarmDateUtils.isSameDay(it.scheduledDateMillis, cellMillis) }
                                    val hasAct = activities.any { FarmDateUtils.isSameDay(it.activityDateMillis, cellMillis) }

                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(vertical = 3.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSelected) ForestGreen else androidx.compose.ui.graphics.Color.Transparent)
                                            .clickable { selectedDateMillis = cellMillis }
                                            .padding(vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = dayNum.toString(),
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (isSelected) PureWhite else MaterialTheme.colorScheme.onSurface
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            if (hasRem) {
                                                Box(
                                                    Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isSelected) PureWhite else ForestGreen)
                                                )
                                            }
                                            if (hasAct) {
                                                Box(
                                                    Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(HarvestGold)
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(ForestGreen))
                        Spacer(Modifier.width(4.dp))
                        Text("Reminder", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(16.dp))
                        Box(Modifier.size(8.dp).clip(CircleShape).background(HarvestGold))
                        Spacer(Modifier.width(4.dp))
                        Text("Activity", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Schedule: ${FarmDateUtils.formatDate(selectedDateMillis)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onAddActivityClick, shape = RoundedCornerShape(12.dp)) {
                        Text("+ Activity")
                    }
                    Button(onClick = onAddReminderClick, shape = RoundedCornerShape(12.dp)) {
                        Text("+ Reminder")
                    }
                }
            }
        }

        if (selectedDayReminders.isEmpty() && selectedDayActivities.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.NotificationsActive,
                    title = "No Tasks on ${FarmDateUtils.formatShortDay(selectedDateMillis)}",
                    subtitle = "Tap + Reminder to schedule watering or fertilizing, or + Activity to log field work."
                )
            }
        } else {
            items(selectedDayReminders, key = { "cal_rem_${it.id}" }) { rem ->
                ReminderCardItem(
                    reminder = rem,
                    onToggle = { onToggleReminder(rem) },
                    onEdit = null,
                    onDelete = null
                )
            }
            items(selectedDayActivities, key = { "cal_act_${it.id}" }) { act ->
                ActivityHistoryCardItem(activity = act, onEdit = null, onDelete = null)
            }
        }
    }
}

@Composable
private fun RemindersTab(
    remindersState: UiState<List<FarmingReminder>>,
    onAddReminderClick: () -> Unit,
    onEditReminderClick: (FarmingReminder) -> Unit,
    onToggleReminder: (FarmingReminder) -> Unit,
    onDeleteReminder: (FarmingReminder) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = onAddReminderClick,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().testTag("reminders_add_btn")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Farming Reminder")
            }
        }

        when (remindersState) {
            is UiState.Loading -> item { KisanLoadingCard("Loading reminders...") }
            is UiState.Error -> item { KisanErrorCard(remindersState.message) }
            is UiState.Success -> {
                if (remindersState.data.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Rounded.NotificationsActive,
                            title = "No Reminders Scheduled",
                            subtitle = "Create alerts for irrigation, fertilizer top-dressing, weeding, and spraying."
                        )
                    }
                } else {
                    items(remindersState.data, key = { it.id }) { rem ->
                        ReminderCardItem(
                            reminder = rem,
                            onToggle = { onToggleReminder(rem) },
                            onEdit = { onEditReminderClick(rem) },
                            onDelete = { onDeleteReminder(rem) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActivityHistoryTab(
    activitiesState: UiState<List<FarmingActivity>>,
    onAddActivityClick: () -> Unit,
    onEditActivityClick: (FarmingActivity) -> Unit,
    onDeleteActivity: (FarmingActivity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = onAddActivityClick,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().testTag("history_log_activity_btn")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Log Farming Activity")
            }
        }

        when (activitiesState) {
            is UiState.Loading -> item { KisanLoadingCard("Loading activity history...") }
            is UiState.Error -> item { KisanErrorCard(activitiesState.message) }
            is UiState.Success -> {
                val list = activitiesState.data
                val totalCost = list.sumOf { it.costInr }
                if (list.isNotEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MeadowTint)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Logged Farm Operations", style = MaterialTheme.typography.labelMedium, color = ForestGreen)
                                    Text("${list.size} activities recorded", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestGreen)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Total Input Cost", style = MaterialTheme.typography.labelMedium, color = ForestGreen)
                                    Text("₹${totalCost.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ForestGreen)
                                }
                            }
                        }
                    }
                    items(list, key = { it.id }) { act ->
                        ActivityHistoryCardItem(
                            activity = act,
                            onEdit = { onEditActivityClick(act) },
                            onDelete = { onDeleteActivity(act) }
                        )
                    }
                } else {
                    item {
                        EmptyStateCard(
                            icon = Icons.Rounded.History,
                            title = "No Activity History Yet",
                            subtitle = "Track sowing, watering, fertilizer doses, pest sprays, and input expenses."
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReminderCardItem(
    reminder: FarmingReminder,
    onToggle: () -> Unit,
    onEdit: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggle) {
                Icon(
                    imageVector = if (reminder.completed) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = if (reminder.completed) "Completed" else "Mark completed",
                    tint = if (reminder.completed) ForestGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = reminder.title,
                    style = MaterialTheme.typography.titleSmall,
                    textDecoration = if (reminder.completed) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    text = "${reminder.category} · ${reminder.cropName} · ${FarmDateUtils.formatShortDay(reminder.scheduledDateMillis)}, ${reminder.timeLabel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (reminder.notes.isNotBlank()) {
                    Text(reminder.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (onEdit != null) {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Rounded.Edit, contentDescription = "Edit reminder", tint = MaterialTheme.colorScheme.primary)
                }
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete reminder", tint = AlertCrimson)
                }
            }
        }
    }
}

@Composable
private fun ActivityHistoryCardItem(
    activity: FarmingActivity,
    onEdit: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MeadowTint),
                contentAlignment = Alignment.Center
            ) {
                Icon(activityOrReminderIcon(activity.activityType), contentDescription = activity.activityType, tint = ForestGreen)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(activity.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    text = "${activity.cropName} · ${activity.activityType} · ${FarmDateUtils.formatDate(activity.activityDateMillis)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val extras = listOfNotNull(
                    activity.quantityUsed.takeIf { it.isNotBlank() },
                    activity.costInr.takeIf { it > 0 }?.let { "₹${it.toInt()}" }
                ).joinToString(" · ")
                if (extras.isNotBlank()) {
                    Text(extras, style = MaterialTheme.typography.labelMedium, color = ForestGreen)
                }
                if (activity.notes.isNotBlank()) {
                    Text(activity.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (onEdit != null) {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Rounded.Edit, contentDescription = "Edit activity", tint = MaterialTheme.colorScheme.primary)
                }
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete activity", tint = AlertCrimson)
                }
            }
        }
    }
}
