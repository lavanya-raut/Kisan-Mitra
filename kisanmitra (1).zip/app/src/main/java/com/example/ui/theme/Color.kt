package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KisanMitra Primary Agriculture Green & White Palette
val ForestGreen = Color(0xFF1B5E20)
val DeepCanopyGreen = Color(0xFF14532D)
val LeafGreen = Color(0xFF2E7D32)
val SproutGreen = Color(0xFF43A047)
val MeadowTint = Color(0xFFE8F5E9)
val SoftSage = Color(0xFFC8E6C9)
val DewSurface = Color(0xFFF6FAF6)
val PureWhite = Color(0xFFFFFFFF)
val SoftOutline = Color(0xFFD5E3D6)
val DeepSlateInk = Color(0xFF152218)
val MutedSageText = Color(0xFF4B6350)

// Accent & Status Colors
val HarvestGold = Color(0xFFE69A00)
val HarvestGoldContainer = Color(0xFFFFF8E1)
val SkyWaterBlue = Color(0xFF0277BD)
val SkyWaterContainer = Color(0xFFE1F5FE)
val AlertCrimson = Color(0xFFC62828)
val AlertCrimsonContainer = Color(0xFFFFEBEE)
val AmberCare = Color(0xFFEF6C00)
val AmberCareContainer = Color(0xFFFFF3E0)

// Dark Theme Agriculture Palette
val DarkSurface = Color(0xFF0F1711)
val DarkSurfaceContainer = Color(0xFF18241B)
val DarkPrimaryGreen = Color(0xFF81C784)
val DarkOnPrimary = Color(0xFF0A3011)
val DarkPrimaryContainer = Color(0xFF1B5E20)
val DarkOnPrimaryContainer = Color(0xFFD7F5D9)
val DarkOutline = Color(0xFF334938)
