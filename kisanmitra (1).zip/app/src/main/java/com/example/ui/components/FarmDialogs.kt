package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CropGuidanceCatalog
import com.example.data.model.FarmConstants
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UserCrop

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditCropDialog(
    initialCrop: UserCrop? = null,
    onDismiss: () -> Unit,
    onSave: (UserCrop) -> Unit
) {
    val isEditing = initialCrop != null
    var selectedCropType by remember { mutableStateOf(initialCrop?.cropType ?: "Wheat") }
    val guide = CropGuidanceCatalog.getGuide(selectedCropType)

    var variety by remember { mutableStateOf(initialCrop?.variety ?: guide.defaultVariety) }
    var plotName by remember { mutableStateOf(initialCrop?.plotName ?: "North Field") }
    var areaText by remember { mutableStateOf(initialCrop?.areaAcres?.toString() ?: "2.0") }
    var daysAgoText by remember {
        mutableStateOf(
            if (initialCrop != null) FarmDateUtils.daysSince(initialCrop.sowingDateMillis).toString() else "0"
        )
    }
    var stage by remember { mutableStateOf(initialCrop?.currentStage ?: "Sowing") }
    var health by remember { mutableStateOf(initialCrop?.healthStatus ?: "Healthy") }
    var progress by remember { mutableFloatStateOf((initialCrop?.progressPercent ?: 15).toFloat()) }
    var notes by remember { mutableStateOf(initialCrop?.notes ?: "") }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(
                text = if (isEditing) "Edit Crop Details" else "Add New Crop",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Select Crop",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FarmConstants.SUPPORTED_CROPS.forEach { cropOption ->
                        FilterChip(
                            selected = selectedCropType == cropOption,
                            onClick = {
                                selectedCropType = cropOption
                                if (!isEditing) {
                                    variety = CropGuidanceCatalog.getGuide(cropOption).defaultVariety
                                }
                            },
                            label = { Text(cropOption) }
                        )
                    }
                }

                OutlinedTextField(
                    value = variety,
                    onValueChange = { variety = it },
                    label = { Text("Seed Variety (e.g. ${guide.defaultVariety})") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("crop_variety_input")
                )

                OutlinedTextField(
                    value = plotName,
                    onValueChange = { plotName = it },
                    label = { Text("Field / Plot Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("crop_plot_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = areaText,
                        onValueChange = { areaText = it },
                        label = { Text("Area (Acres)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("crop_area_input")
                    )
                    OutlinedTextField(
                        value = daysAgoText,
                        onValueChange = { daysAgoText = it },
                        label = { Text("Sown (Days Ago)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Text(
                    text = "Current Growth Stage",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FarmConstants.CROP_STAGES.forEach { stageOption ->
                        FilterChip(
                            selected = stage == stageOption,
                            onClick = {
                                stage = stageOption
                                progress = FarmConstants.defaultProgressForStage(stageOption).toFloat()
                            },
                            label = { Text(stageOption, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Column {
                    Text(
                        text = "Growth Progress: ${progress.toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = progress,
                        onValueChange = { progress = it },
                        valueRange = 0f..100f
                    )
                }

                Text(
                    text = "Crop Health",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FarmConstants.HEALTH_STATUSES.forEach { statusOption ->
                        FilterChip(
                            selected = health == statusOption,
                            onClick = { health = statusOption },
                            label = { Text(statusOption, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Field Notes (Optional)") },
                    maxLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedArea = areaText.trim().toDoubleOrNull()
                    if (plotName.isBlank()) {
                        validationError = "Please enter a plot or field name."
                        return@Button
                    }
                    if (parsedArea == null || parsedArea <= 0.0) {
                        validationError = "Please enter a valid area in acres (> 0)."
                        return@Button
                    }
                    val daysAgo = (daysAgoText.trim().toIntOrNull() ?: 0).coerceIn(0, 400)
                    val sowingMillis = System.currentTimeMillis() - (daysAgo * 86_400_000L)
                    val durationMillis = CropGuidanceCatalog.getGuide(selectedCropType).durationDays * 86_400_000L
                    val harvestMillis = sowingMillis + durationMillis

                    onSave(
                        (initialCrop ?: UserCrop()).copy(
                            cropType = selectedCropType,
                            variety = variety.trim().ifBlank { guide.defaultVariety },
                            plotName = plotName.trim(),
                            areaAcres = parsedArea,
                            sowingDateMillis = sowingMillis,
                            expectedHarvestMillis = harvestMillis,
                            currentStage = stage,
                            healthStatus = health,
                            progressPercent = progress.toInt().coerceIn(0, 100),
                            notes = notes.trim()
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_crop_button")
            ) {
                Text(if (isEditing) "Update Crop" else "Save Crop")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditReminderDialog(
    crops: List<UserCrop>,
    initialReminder: FarmingReminder? = null,
    defaultDayOffset: Int = 0,
    onDismiss: () -> Unit,
    onSave: (FarmingReminder) -> Unit
) {
    val isEditing = initialReminder != null
    var title by remember { mutableStateOf(initialReminder?.title ?: "") }
    var category by remember { mutableStateOf(initialReminder?.category ?: "Irrigation") }
    var selectedCropName by remember { mutableStateOf(initialReminder?.cropName ?: (crops.firstOrNull()?.cropType ?: "All Crops")) }
    var selectedCropId by remember { mutableStateOf(initialReminder?.cropId ?: (crops.firstOrNull()?.id ?: "")) }
    var dayOffset by remember {
        mutableIntStateOf(
            if (initialReminder != null) {
                ((initialReminder.scheduledDateMillis - FarmDateUtils.startOfTodayMillis()) / 86_400_000L).toInt().coerceIn(0, 30)
            } else {
                defaultDayOffset
            }
        )
    }
    var timeLabel by remember { mutableStateOf(initialReminder?.timeLabel ?: "06:30 AM") }
    var repeatFrequency by remember { mutableStateOf(initialReminder?.repeatFrequency ?: "Once") }
    var notes by remember { mutableStateOf(initialReminder?.notes ?: "") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val timePresets = listOf("06:00 AM", "06:30 AM", "07:30 AM", "09:00 AM", "04:30 PM", "06:00 PM")
    val dayPresets = listOf(0 to "Today", 1 to "Tomorrow", 2 to "+2 Days", 3 to "+3 Days", 7 to "+1 Week")

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(
                text = if (isEditing) "Edit Farming Reminder" else "New Farming Reminder",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title (e.g. First Urea Top Dressing)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("reminder_title_input")
                )

                Text("Category", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FarmConstants.REMINDER_CATEGORIES.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Linked Crop", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedCropName == "All Crops",
                        onClick = {
                            selectedCropName = "All Crops"
                            selectedCropId = ""
                        },
                        label = { Text("All Crops", style = MaterialTheme.typography.labelSmall) }
                    )
                    crops.forEach { c ->
                        val label = "${c.cropType} (${c.plotName})"
                        FilterChip(
                            selected = selectedCropId == c.id && selectedCropId.isNotBlank(),
                            onClick = {
                                selectedCropName = c.cropType
                                selectedCropId = c.id
                            },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    if (crops.isEmpty()) {
                        FarmConstants.SUPPORTED_CROPS.take(4).forEach { cropName ->
                            FilterChip(
                                selected = selectedCropName == cropName,
                                onClick = {
                                    selectedCropName = cropName
                                    selectedCropId = ""
                                },
                                label = { Text(cropName, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                Text("Schedule Date", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    dayPresets.forEach { (offset, label) ->
                        FilterChip(
                            selected = dayOffset == offset,
                            onClick = { dayOffset = offset },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Time of Day", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    timePresets.forEach { slot ->
                        FilterChip(
                            selected = timeLabel == slot,
                            onClick = { timeLabel = slot },
                            label = { Text(slot, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Repeat", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FarmConstants.REPEAT_FREQUENCIES.forEach { freq ->
                        FilterChip(
                            selected = repeatFrequency == freq,
                            onClick = { repeatFrequency = freq },
                            label = { Text(freq, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Dosage (Optional)") },
                    maxLines = 2,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (validationError != null) {
                    Text(validationError!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        validationError = "Please enter a reminder title."
                        return@Button
                    }
                    onSave(
                        (initialReminder ?: FarmingReminder()).copy(
                            title = title.trim(),
                            category = category,
                            cropName = selectedCropName,
                            cropId = selectedCropId,
                            scheduledDateMillis = FarmDateUtils.dayMillisOffset(dayOffset),
                            timeLabel = timeLabel,
                            repeatFrequency = repeatFrequency,
                            notes = notes.trim()
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_reminder_button")
            ) {
                Text(if (isEditing) "Update" else "Save Reminder")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditActivityDialog(
    crops: List<UserCrop>,
    preselectedCrop: UserCrop? = null,
    initialActivity: FarmingActivity? = null,
    onDismiss: () -> Unit,
    onSave: (FarmingActivity) -> Unit
) {
    val isEditing = initialActivity != null
    var title by remember { mutableStateOf(initialActivity?.title ?: "") }
    var activityType by remember { mutableStateOf(initialActivity?.activityType ?: "Irrigation") }
    var selectedCropName by remember {
        mutableStateOf(
            initialActivity?.cropName ?: preselectedCrop?.cropType ?: crops.firstOrNull()?.cropType ?: "All Crops"
        )
    }
    var selectedCropId by remember {
        mutableStateOf(
            initialActivity?.cropId ?: preselectedCrop?.id ?: crops.firstOrNull()?.id ?: ""
        )
    }
    var quantityUsed by remember { mutableStateOf(initialActivity?.quantityUsed ?: "") }
    var costText by remember {
        mutableStateOf(
            if (initialActivity != null && initialActivity.costInr > 0) initialActivity.costInr.toInt().toString() else ""
        )
    }
    var notes by remember { mutableStateOf(initialActivity?.notes ?: "") }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(
                text = if (isEditing) "Edit Activity Record" else "Log Farming Activity",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Activity Summary (e.g. Drip Irrigation Run)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("activity_title_input")
                )

                Text("Activity Type", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FarmConstants.ACTIVITY_TYPES.forEach { type ->
                        FilterChip(
                            selected = activityType == type,
                            onClick = { activityType = type },
                            label = { Text(type, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Crop", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedCropName == "All Crops",
                        onClick = {
                            selectedCropName = "All Crops"
                            selectedCropId = ""
                        },
                        label = { Text("All Crops", style = MaterialTheme.typography.labelSmall) }
                    )
                    crops.forEach { c ->
                        FilterChip(
                            selected = selectedCropId == c.id && selectedCropId.isNotBlank(),
                            onClick = {
                                selectedCropName = c.cropType
                                selectedCropId = c.id
                            },
                            label = { Text("${c.cropType} (${c.plotName})", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = quantityUsed,
                        onValueChange = { quantityUsed = it },
                        label = { Text("Input / Duration") },
                        placeholder = { Text("25 kg / 2 hrs") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1.2f)
                    )
                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it },
                        label = { Text("Cost (₹)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(0.8f)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Observations / Notes") },
                    maxLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (validationError != null) {
                    Text(validationError!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        validationError = "Please describe the farming activity."
                        return@Button
                    }
                    val parsedCost = costText.trim().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                    onSave(
                        (initialActivity ?: FarmingActivity()).copy(
                            title = title.trim(),
                            activityType = activityType,
                            cropName = selectedCropName,
                            cropId = selectedCropId,
                            activityDateMillis = initialActivity?.activityDateMillis?.takeIf { it > 0 } ?: System.currentTimeMillis(),
                            quantityUsed = quantityUsed.trim(),
                            costInr = parsedCost,
                            notes = notes.trim()
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_activity_button")
            ) {
                Text(if (isEditing) "Update" else "Log Activity")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
