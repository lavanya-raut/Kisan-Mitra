package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.FarmerProfile
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UiState
import com.example.data.model.UserCrop
import com.example.data.model.WeatherSnapshot
import com.example.ui.components.CropIconBadge
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FarmDateUtils
import com.example.ui.components.FarmHorizonBanner
import com.example.ui.components.HealthStatusChip
import com.example.ui.components.KisanErrorCard
import com.example.ui.components.KisanLoadingCard
import com.example.ui.components.KisanMitraLogoMark
import com.example.ui.components.SectionHeader
import com.example.ui.components.StageChip
import com.example.ui.components.activityOrReminderIcon
import com.example.ui.components.weatherCodeIcon
import com.example.ui.theme.AmberCare
import com.example.ui.theme.AmberCareContainer
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.HarvestGold
import com.example.ui.theme.HarvestGoldContainer
import com.example.ui.theme.MeadowTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SkyWaterBlue
import com.example.ui.theme.SkyWaterContainer
import java.util.Calendar

@Composable
fun HomeDashboardScreen(
    profileState: UiState<FarmerProfile?>,
    cropsState: UiState<List<UserCrop>>,
    remindersState: UiState<List<FarmingReminder>>,
    activitiesState: UiState<List<FarmingActivity>>,
    weatherState: UiState<WeatherSnapshot>,
    onOpenWeather: () -> Unit,
    onOpenMyCrops: () -> Unit,
    onOpenCropDetail: (UserCrop) -> Unit,
    onOpenCropGuidanceHub: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenActivityHistory: () -> Unit,
    onAddCropClick: () -> Unit,
    onAddReminderClick: () -> Unit,
    onLogActivityClick: () -> Unit,
    onToggleReminder: (FarmingReminder) -> Unit,
    onRetryWeather: () -> Unit
) {
    val profile = (profileState as? UiState.Success)?.data
    val crops = (cropsState as? UiState.Success)?.data.orEmpty()
    val reminders = (remindersState as? UiState.Success)?.data.orEmpty()
    val activities = (activitiesState as? UiState.Success)?.data.orEmpty()

    val pendingReminders = reminders.filter { !it.completed }
    val todayMillis = System.currentTimeMillis()
    val todaysActivities = activities.filter { FarmDateUtils.isSameDay(it.activityDateMillis, todayMillis) }

    val farmerFirstName = profile?.fullName
        ?.trim()
        ?.substringBefore(" ")
        ?.ifBlank { "Farmer" } ?: "Farmer"

    val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 4..11 -> "Good Morning"
        in 12..16 -> "Good Afternoon"
        else -> "Good Evening"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // 1. Official KisanMitra Top Brand Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    KisanMitraLogoMark(size = 44.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.app_tagline),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                FilledTonalIconButton(
                    onClick = onOpenCalendar,
                    modifier = Modifier.testTag("dashboard_reminders_bell")
                ) {
                    BadgedBox(
                        badge = {
                            if (pendingReminders.isNotEmpty()) {
                                Badge(containerColor = HarvestGold, contentColor = PureWhite) {
                                    Text(pendingReminders.size.coerceAtMost(9).toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.NotificationsActive,
                            contentDescription = "Upcoming reminders"
                        )
                    }
                }
            }
        }

        // 2. Welcome Banner with Sunlit Indian Farmland Horizon
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                ) {
                    FarmHorizonBanner(modifier = Modifier.fillMaxSize())
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Namaste, $farmerFirstName",
                                style = MaterialTheme.typography.headlineSmall,
                                color = PureWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$greeting! Ready for a productive day in your fields.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = PureWhite.copy(alpha = 0.92f)
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = PureWhite.copy(alpha = 0.22f)
                            ) {
                                Text(
                                    text = "${crops.size} Active Crops",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = PureWhite.copy(alpha = 0.22f)
                            ) {
                                Text(
                                    text = "${pendingReminders.size} Pending Tasks",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Live Weather Summary Card
        item {
            SectionHeader(
                title = "Live Farm Weather",
                actionLabel = "Full Forecast",
                onActionClick = onOpenWeather,
                actionTestTag = "dashboard_weather_more"
            )
            Spacer(modifier = Modifier.height(8.dp))
            when (weatherState) {
                is UiState.Loading -> KisanLoadingCard("Fetching live weather from Open-Meteo...")
                is UiState.Error -> KisanErrorCard(message = weatherState.message, onRetry = onRetryWeather)
                is UiState.Success -> DashboardWeatherCard(
                    weather = weatherState.data,
                    onClick = onOpenWeather
                )
            }
        }

        // 4. Quick-Access Feature Cards (2x2 Farmer Grid)
        item {
            SectionHeader(title = "Quick Access")
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickAccessTile(
                        icon = Icons.Rounded.MenuBook,
                        title = "Crop Guidance",
                        subtitle = "8 Indian crops",
                        bg = MeadowTint,
                        tint = ForestGreen,
                        onClick = onOpenCropGuidanceHub,
                        modifier = Modifier.weight(1f).testTag("quick_guidance_card")
                    )
                    QuickAccessTile(
                        icon = Icons.Rounded.Timeline,
                        title = "Growth Tracker",
                        subtitle = "Track stages",
                        bg = SkyWaterContainer,
                        tint = SkyWaterBlue,
                        onClick = onOpenMyCrops,
                        modifier = Modifier.weight(1f).testTag("quick_growth_card")
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickAccessTile(
                        icon = Icons.Rounded.Add,
                        title = "Add Reminder",
                        subtitle = "Set farm alert",
                        bg = HarvestGoldContainer,
                        tint = HarvestGold,
                        onClick = onAddReminderClick,
                        modifier = Modifier.weight(1f).testTag("quick_reminder_card")
                    )
                    QuickAccessTile(
                        icon = Icons.Rounded.History,
                        title = "Activity History",
                        subtitle = "${activities.size} logged",
                        bg = AmberCareContainer,
                        tint = AmberCare,
                        onClick = onOpenActivityHistory,
                        modifier = Modifier.weight(1f).testTag("quick_history_card")
                    )
                }
            }
        }

        // 5. My Crops Horizontal Strip
        item {
            SectionHeader(
                title = "My Crops",
                actionLabel = "+ Add Crop",
                onActionClick = onAddCropClick,
                actionTestTag = "dashboard_add_crop_btn"
            )
            Spacer(modifier = Modifier.height(8.dp))
            when (cropsState) {
                is UiState.Loading -> KisanLoadingCard("Loading your crops...")
                is UiState.Error -> KisanErrorCard(cropsState.message)
                is UiState.Success -> {
                    if (crops.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Rounded.Eco,
                            title = "No Crops Added Yet",
                            subtitle = "Add Wheat, Rice, Cotton, Soybean, Sugarcane, Maize, Tomato, or Onion to start lifecycle tracking.",
                            ctaLabel = "Add Your First Crop",
                            onCtaClick = onAddCropClick,
                            ctaTestTag = "empty_add_first_crop_btn"
                        )
                    } else {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(crops, key = { it.id }) { crop ->
                                DashboardCropCard(
                                    crop = crop,
                                    onClick = { onOpenCropDetail(crop) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Today's Farming Activities
        item {
            SectionHeader(
                title = "Today's Farming Activities",
                actionLabel = "+ Log Activity",
                onActionClick = onLogActivityClick,
                actionTestTag = "dashboard_log_activity_btn"
            )
            Spacer(modifier = Modifier.height(8.dp))
            when (activitiesState) {
                is UiState.Loading -> KisanLoadingCard("Loading activities...")
                is UiState.Error -> KisanErrorCard(activitiesState.message)
                is UiState.Success -> {
                    if (todaysActivities.isEmpty()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onLogActivityClick() }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(MeadowTint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = null, tint = ForestGreen)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "No activity logged today",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = "Tap to record irrigation, fertilizer, weeding, or field check.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            todaysActivities.take(3).forEach { act ->
                                DashboardActivityRow(activity = act, onClick = onOpenActivityHistory)
                            }
                        }
                    }
                }
            }
        }

        // 7. Upcoming Reminders
        item {
            SectionHeader(
                title = "Upcoming Reminders",
                actionLabel = "View All",
                onActionClick = onOpenCalendar,
                actionTestTag = "dashboard_view_reminders_btn"
            )
            Spacer(modifier = Modifier.height(8.dp))
            when (remindersState) {
                is UiState.Loading -> KisanLoadingCard("Loading reminders...")
                is UiState.Error -> KisanErrorCard(remindersState.message)
                is UiState.Success -> {
                    if (pendingReminders.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Rounded.NotificationsActive,
                            title = "All Caught Up!",
                            subtitle = "Schedule irrigation, fertilizer, or pest-scouting reminders so nothing slips.",
                            ctaLabel = "Add Reminder",
                            onCtaClick = onAddReminderClick,
                            ctaTestTag = "empty_add_reminder_btn"
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            pendingReminders.take(4).forEach { reminder ->
                                DashboardReminderRow(
                                    reminder = reminder,
                                    onToggle = { onToggleReminder(reminder) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardWeatherCard(
    weather: WeatherSnapshot,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("dashboard_weather_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = weather.cityName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = weather.conditionLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = "Open weather details",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MeadowTint),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = weatherCodeIcon(weather.weatherCode),
                            contentDescription = weather.conditionLabel,
                            tint = ForestGreen,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "${weather.temperatureC.toInt()}°C",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Feels like ${weather.feelsLikeC.toInt()}°C",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    WeatherMetricPill(Icons.Rounded.WaterDrop, "${weather.humidityPercent}% RH · ${weather.rainChanceTodayPercent}% Rain")
                    WeatherMetricPill(Icons.Rounded.Air, "${weather.windSpeedKmh.toInt()} km/h Wind")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = if (weather.advisory.isWarning) AmberCareContainer else MeadowTint
            ) {
                Text(
                    text = "${weather.advisory.title}: ${weather.advisory.sprayStatus}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (weather.advisory.isWarning) AmberCare else ForestGreen,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun WeatherMetricPill(icon: ImageVector, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun QuickAccessTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    bg: Color,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bg),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = tint, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun DashboardCropCard(
    crop: UserCrop,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(230.dp)
            .clickable(onClick = onClick)
            .testTag("dashboard_crop_card_${crop.cropType.lowercase()}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CropIconBadge(cropType = crop.cropType, size = 40.dp)
                HealthStatusChip(status = crop.healthStatus)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = crop.cropType,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${crop.plotName} · ${crop.areaAcres} ac",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StageChip(stage = crop.currentStage)
                Text(
                    text = "${crop.progressPercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { crop.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(50)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer
            )
        }
    }
}

@Composable
private fun DashboardActivityRow(
    activity: FarmingActivity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MeadowTint),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = activityOrReminderIcon(activity.activityType),
                    contentDescription = activity.activityType,
                    tint = ForestGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${activity.cropName} · ${activity.activityType}" +
                        if (activity.quantityUsed.isNotBlank()) " · ${activity.quantityUsed}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (activity.costInr > 0) {
                Text(
                    text = "₹${activity.costInr.toInt()}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun DashboardReminderRow(
    reminder: FarmingReminder,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.testTag("toggle_reminder_${reminder.id}")
            ) {
                Icon(
                    imageVector = if (reminder.completed) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = if (reminder.completed) "Mark pending" else "Mark completed",
                    tint = if (reminder.completed) ForestGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = reminder.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${reminder.cropName} · ${FarmDateUtils.formatShortDay(reminder.scheduledDateMillis)} at ${reminder.timeLabel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Text(
                    text = reminder.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}
