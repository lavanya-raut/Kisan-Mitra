package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.FarmConstants
import com.example.data.model.FarmerProfile
import com.example.data.model.FarmingActivity
import com.example.data.model.FarmingReminder
import com.example.data.model.UiState
import com.example.data.model.UserCrop
import com.example.ui.components.KisanErrorCard
import com.example.ui.components.KisanLoadingCard
import com.example.ui.components.KisanMitraLogoMark
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.MeadowTint
import com.example.ui.theme.PureWhite

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    profileState: UiState<FarmerProfile?>,
    cropsState: UiState<List<UserCrop>>,
    remindersState: UiState<List<FarmingReminder>>,
    activitiesState: UiState<List<FarmingActivity>>,
    isSaving: Boolean,
    onSaveProfile: (FarmerProfile) -> Unit,
    onSignOut: () -> Unit
) {
    val crops = (cropsState as? UiState.Success)?.data.orEmpty()
    val pendingReminders = (remindersState as? UiState.Success)?.data.orEmpty().count { !it.completed }
    val activitiesCount = (activitiesState as? UiState.Success)?.data.orEmpty().size

    val loadedProfile = (profileState as? UiState.Success)?.data

    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var stateName by remember { mutableStateOf("") }
    var farmSizeText by remember { mutableStateOf("2.0") }
    var soilType by remember { mutableStateOf("Black Cotton") }
    var irrigationType by remember { mutableStateOf("Borewell") }
    var initializedForUid by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(loadedProfile) {
        if (loadedProfile != null && initializedForUid != loadedProfile.userId) {
            fullName = loadedProfile.fullName
            phone = loadedProfile.phone
            village = loadedProfile.village
            district = loadedProfile.district
            stateName = loadedProfile.state
            farmSizeText = loadedProfile.farmSizeAcres.toString()
            soilType = loadedProfile.soilType
            irrigationType = loadedProfile.irrigationType
            initializedForUid = loadedProfile.userId
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Farmer Profile",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Manage your farm details & KisanMitra account",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        when (profileState) {
            is UiState.Loading -> item { KisanLoadingCard("Loading farmer profile...") }
            is UiState.Error -> item { KisanErrorCard(profileState.message) }
            is UiState.Success -> {
                val p = profileState.data ?: FarmerProfile()

                // Farmer Identity Header Card
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = ForestGreen)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(PureWhite.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.Person, contentDescription = null, tint = PureWhite, modifier = Modifier.size(32.dp))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = p.fullName.ifBlank { "Kisan Farmer" },
                                    style = MaterialTheme.typography.titleLarge,
                                    color = PureWhite,
                                    fontWeight = FontWeight.Bold
                                )
                                if (p.email.isNotBlank()) {
                                    Text(
                                        text = p.email,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PureWhite.copy(alpha = 0.85f)
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = PureWhite.copy(alpha = 0.9f), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    val loc = listOf(p.village, p.district, p.state)
                                        .filter { it.isNotBlank() }
                                        .joinToString(", ")
                                        .ifBlank { p.preferredCity }
                                    Text(
                                        text = loc,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = PureWhite.copy(alpha = 0.9f)
                                    )
                                }
                            }
                            KisanMitraLogoMark(size = 40.dp)
                        }
                    }
                }

                // Farm KPIs Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ProfileStatBox("${crops.size}", "Crops", Modifier.weight(1f))
                        ProfileStatBox("${p.farmSizeAcres}", "Acres", Modifier.weight(1f))
                        ProfileStatBox("$pendingReminders", "Pending", Modifier.weight(1f))
                        ProfileStatBox("$activitiesCount", "Logs", Modifier.weight(1f))
                    }
                }

                // Editable Farmer Profile Form
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Personal & Farm Details",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )

                            OutlinedTextField(
                                value = fullName,
                                onValueChange = { fullName = it },
                                label = { Text("Farmer Full Name") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                            )

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Mobile Number") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = village,
                                    onValueChange = { village = it },
                                    label = { Text("Village / Town") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = district,
                                    onValueChange = { district = it },
                                    label = { Text("District") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = stateName,
                                    onValueChange = { stateName = it },
                                    label = { Text("State") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(1.2f)
                                )
                                OutlinedTextField(
                                    value = farmSizeText,
                                    onValueChange = { farmSizeText = it },
                                    label = { Text("Land (Acres)") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(0.8f)
                                )
                            }

                            Text("Soil Type", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                FarmConstants.SOIL_TYPES.forEach { st ->
                                    FilterChip(
                                        selected = soilType == st,
                                        onClick = { soilType = st },
                                        label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }

                            Text("Irrigation Source", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                FarmConstants.IRRIGATION_TYPES.forEach { irr ->
                                    FilterChip(
                                        selected = irrigationType == irr,
                                        onClick = { irrigationType = irr },
                                        label = { Text(irr, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    val acres = farmSizeText.trim().toDoubleOrNull()?.coerceAtLeast(0.0) ?: p.farmSizeAcres
                                    onSaveProfile(
                                        p.copy(
                                            fullName = fullName.trim().ifBlank { p.fullName },
                                            phone = phone.trim(),
                                            village = village.trim(),
                                            district = district.trim(),
                                            state = stateName.trim(),
                                            farmSizeAcres = acres,
                                            soilType = soilType,
                                            irrigationType = irrigationType
                                        )
                                    )
                                },
                                enabled = !isSaving,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("save_profile_button")
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = PureWhite, strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Save Farmer Profile")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sign Out Card
        item {
            OutlinedButton(
                onClick = onSignOut,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertCrimson),
                border = BorderStroke(1.dp, AlertCrimson.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out of KisanMitra")
            }
        }
    }
}

@Composable
private fun ProfileStatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MeadowTint)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.titleLarge, color = ForestGreen, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = ForestGreen)
        }
    }
}
